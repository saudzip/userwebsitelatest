let vendorImageData;
let SelectedVendorData = JSON.parse(localStorage.getItem("vendorData"));
console.log("selectedVendorData============>",SelectedVendorData);
async function getCategories() {
  try {
    const response = await fetch(`http://100.27.227.121:8000/api/categories`);
    const vendorData = await fetch(`http://100.27.227.121:8000/api/vendors`)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    const vData = await vendorData.json();
    const categories = data.result.data;
    vendorImageData = vData.vendors.data;
    console.log("Categories:", categories);
    console.log("vendorImageData", vendorImageData);
    return categories;
  } catch (error) {
    console.error("Fetch error:", error.message);
    return null;
  }
}


document.addEventListener("DOMContentLoaded", async function () {

  const categories = await getCategories();

  let service;
  const selectedService = localStorage.getItem("moreServices");
  if (selectedService) {
    service = JSON.parse(selectedService);
    populateInfoPanel(service);
    populateMoreContent(service);
    console.log("Selected Service:", service);
  } else {
    console.log("No selected service found in local storage.");
    return;
  }

  // allVendorsData is your full array of vendors that includes `.images` for each vendor
  // const matchedVendor = vendorImageData.find(v => v.id === service.vendor.id);
  const matchedVendor = vendorImageData.find(
    v => v.id === service.vendor?.id
  );


  console.log("matchedVendor", matchedVendor);

  let vendorImages = [];

  if (matchedVendor && Array.isArray(matchedVendor.images)) {
    vendorImages = matchedVendor.images
      .slice(0, 5)
      .map(img => img?.image_path || "");
  }

  const [vImage1, vImage2, vImage3, vImage4, vImage5] = vendorImages;


  // console.log(service.vendor.id, matchedVendor.id);

  console.log("=================> vImage1 === ", vImage1);
  console.log("=================> vImage2 === ", vImage2);
  console.log("=================> vImage3 === ", vImage3);
  console.log("=================> vImage4 === ", vImage4);
  console.log("=================> vImage5 === ", vImage5);


  const wellthsection = document.getElementById("wellth-section");
  wellthsection.innerHTML = "";
  const wellthWraper = document.createElement("div");


  // Defensive check for images


const SelectedVendorData = JSON.parse(localStorage.getItem("vendorData") || "{}");

const city = SelectedVendorData?.cities?.[0]?.name || "N/A";
const country = SelectedVendorData?.countries?.[0]?.name || "N/A";

const businessHours = SelectedVendorData?.business_hours?.[0]
  ? `${SelectedVendorData.business_hours[0].open} - ${SelectedVendorData.business_hours[0].close}`
  : "No Hours";

const businessDays = Array.isArray(SelectedVendorData.business_days) && SelectedVendorData.business_days.length > 0
  ? `${SelectedVendorData.business_days[0]} - ${SelectedVendorData.business_days.at(-1)}`
  : "No Days";

// Image Fallbacks
const getImageUrl = (index) =>
  SelectedVendorData?.images?.[index]?.image_path
    ? `${SelectedVendorData.images[index].image_path}`
    : "assets/images/placeholder.jpg"; // fallback image path


    console.log("====================>",getImageUrl(0));

wellthWraper.innerHTML = `
  <div class="">
    <h2>${SelectedVendorData.name || "N/A"}</h2>
    <p class="wellth-subtitle mt-4">${SelectedVendorData.description || "N/A"}</p>

    <!-- Header Row -->
    <div class="wellth-header-row">
      <div class="left">
        <div class="d-flex align-items-center gap-2">
          <img src="assets/icons/location.svg" alt="Location" width="20" />
          <small class="text-secondary">${city}, ${country}</small>
        </div>
        <div class="d-flex align-items-center gap-2">
          <img src="assets/icons/clock.svg" alt="Clock" width="20" />
          <small class="text-secondary">${businessHours}, ${businessDays}</small>
        </div>
      </div>

      <div class="right">
        <div class="avatar-group">
          <img src="assets/images/multiple-user.png" class="me-3" width="24" height="24" alt="Group" />
          <img src="assets/images/avatar1.jpg" class="rounded-circle" width="32" alt="User1" />
          <img src="assets/images/avatar.png" class="rounded-circle" width="32" alt="User2" />
          <img src="assets/images/avatar4.jpg" class="rounded-circle" width="32" alt="User3" />
        </div>
        <div class="d-flex align-items-center gap-1">
          <img src="assets/icons/Star 3.svg" alt="Star" width="20" class="me-1" />
          <strong class="me-1">5.0</strong>
          <small class="text-secondary">(312)</small>
        </div>
      </div>
    </div>

    <!-- Image Gallery -->
    <div class="wellth-gallery">
      <div class="wellth-main-img" style="background-image: url('${getImageUrl(0)}')"></div>
      <div class="wellth-thumbs">
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(1)}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(2)}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(3)}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(4)}')"></div>
      </div>
    </div>
  </div>
`;


  wellthsection.appendChild(wellthWraper);
  //////////////////////////////////////////////// show Categorries ////////////////////////////////////////////////////////
  const categoriesRapper = document.getElementById("categories-rapper");
  categoriesRapper.innerHTML = "";

  categories.forEach((element, index) => {
    const catIcon = element.icon || "assets/icons/Frame 2.svg";

    const categoryWrapper = document.createElement("div");
    categoryWrapper.innerHTML = `
    <button class="cat-btn ${index === 0 ? 'selected' : ''}">
      <img src="${catIcon}" alt="${element.name}" />
      <span>${element.name}</span>
    </button>
  `;
    categoriesRapper.appendChild(categoryWrapper);
  });


  const allCatButtons = categoriesRapper.querySelectorAll(".cat-btn");
  allCatButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      allCatButtons.forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
    });
  });

  /////////////////////////////////////////////////////////////////////////////////////////////////
  const navLinks = document.querySelectorAll(".nav-link");
  const tabContents = document.querySelectorAll(".tab-content");

  navLinks.forEach(link => {
    link.addEventListener("click", function (e) {
      e.preventDefault();

      // Remove active class from all nav links
      navLinks.forEach(l => l.classList.remove("active"));
      this.classList.add("active");

      // Hide all tab contents
      const selectedTab = this.getAttribute("data-tab");
      tabContents.forEach(content => {
        content.style.display = content.id === selectedTab ? "flex" : "none";
      });
    });
  });

  // Optional: Ensure correct tab is visible on page load (first tab)
  tabContents.forEach(content => {
    content.style.display = content.id === "recommended" ? "flex" : "none";
  });

  /////////////////////////////////////////////////////////////// Fetching Apis for tabs //////////////////////////////////////////
  let ApiServicesData = [];
  let ApiPacksData = [];
  let ApiMemberShipData = [];
  // Store all services in one place
  let allServices = [];

  async function fetchAllServices() {
    try {
      const [responseServiceApi, responsePackApi, responseMembershipApi] = await Promise.all([
        fetch('http://100.27.227.121:8000/api/services'),
        fetch('http://100.27.227.121:8000/api/packs'),
        fetch('http://100.27.227.121:8000/api/memberships'),
      ]);

      // Check for response errors
      if (!responseServiceApi.ok || !responsePackApi.ok || !responseMembershipApi.ok) {
        throw new Error('One or more API requests failed');
      }

      const servicesData = await responseServiceApi.json();
      const packsData = await responsePackApi.json();
      const membershipData = await responseMembershipApi.json();

      // Assign data to global variables
      ApiServicesData = servicesData.data?.data || [];
      ApiPacksData = packsData.data?.data || [];
      ApiMemberShipData = membershipData.data?.data || [];
      // Add after you fetch and render
      allServices = [...ApiServicesData, ...ApiPacksData, ...ApiMemberShipData];

      console.log("Services:", ApiServicesData);
      console.log("Packs:", ApiPacksData);
      console.log("Memberships:", ApiMemberShipData);
      renderCardsByType(ApiServicesData, "single");
      renderCardsByType(ApiPacksData, "packs");
      renderCardsByType(ApiMemberShipData, "membership");
      const recommendedServices = ApiServicesData; // show all services
      renderCardsByType(recommendedServices, "recommended");


      // Optionally, you can now call a function to render the data
      // renderTabsData();
    } catch (error) {
      console.error("Failed to fetch service data:", error);
    }
  }

  fetchAllServices();


  function generateSessionCard(service) {
    return `
    <div class="session-card" data-id="${service.id}">
      <h5>${service.service_name || "Untitled Service"}</h5>
      <p>
        ${service.service_description?.slice(0, 60) || "No description"}...
        <a href="#" class="read-more text-muted" data-id="${service.id}">read more</a>
      </p>
      <div class="session-meta">
        <div class="d-flex align-items-center">
          <span class="text-dark">${service.vendor?.currency || "$"} ${service.prices || "0.00"}</span>
        </div>
        <div class="d-flex align-items-center">
          <img src="assets/icons/clock.svg" alt="Duration">
          <small>${(service.durations || []).join(' Min, ')} Mins</small>
        </div>
      </div>
      <button class="btn-add">
        <img src="assets/icons/Add_Icon_Wellth.png" alt="icon" class="img-fluid">
      </button>
    </div>
  `;
  }



  document.querySelector('.session-list').addEventListener('click', function (e) {
    if (e.target.classList.contains('read-more')) {
      e.preventDefault();
      this.style.display = 'none';
      document.getElementById('detail-card').style.display = 'block';
    }
  });






  // Event delegation for read-more
  document.querySelector('.session-list').addEventListener('click', function (e) {
    if (e.target.classList.contains('read-more')) {
      e.preventDefault();
      const serviceId = e.target.dataset.id;
      const selectedService = allServices.find(s => s.id == serviceId);
      if (selectedService) {
        populateDetailCard(selectedService);
        document.querySelector('.session-list').style.display = 'none';
        document.getElementById('detail-card').style.display = 'block';
      }
    }

    if (e.target.classList.contains('read-less')) {
      document.getElementById('detail-card').style.display = 'none';
      document.querySelector('.session-list').style.display = 'block';
    }
  });


  function populateDetailCard(service) {
    const detail = document.getElementById('detail-card');
    const imageEl = detail.querySelector('.main-img');

    if (imageEl && service.images && service.images.length > 0) {
      imageEl.src = `https://livoadmin.falakbhatti.com/storage/app/public/${service.images[0].image_path}`;
    } else {
      imageEl.src = "assets/images/service3.jpg";
    }

    detail.querySelector('h5').textContent = service.service_name || 'Service';
    detail.querySelector('.rating span').textContent = "5.0 (312)";
    detail.querySelector('.meta div:first-child').textContent = `${service.vendor?.currency || "$"} ${service.prices || "0.00"}`;
    detail.querySelector('.meta small').textContent = `${service.durations.join('Min, ')}Min`;
    detail.querySelector('.description p').textContent = service.service_description || 'No description';
    detail.querySelector('.benefits p').textContent = service.service_benefits || 'No benefits listed';

    // 🔽 Set the ID for later use
    const addBtn = detail.querySelector('#detail-add-btn');
    if (addBtn) {
      addBtn.dataset.id = service.id;
    }
  }



  // Replace both separate event handlers with this unified one
  document.body.addEventListener('click', e => {
    const addBtn = e.target.closest('.btn-add');
    const detailAddBtn = e.target.closest('#detail-add-btn');

    if (addBtn || detailAddBtn) {
      let selectedService;

      if (addBtn) {
        // Handle regular .btn-add clicks
        const sessionCard = addBtn.closest('.session-card');
        const serviceId = sessionCard?.dataset.id;
        selectedService = allServices.find(s => s.id == serviceId);
      } else if (detailAddBtn) {
        // Handle #detail-add-btn clicks
        const serviceId = detailAddBtn.dataset.id;
        selectedService = allServices.find(s => s.id == serviceId);
      }

      // Check which panel is currently visible and toggle*
      if (!cardwellth_ID.classList.contains('hide')) {
        // Hide panel #1, show panel #2 (expanded)
        cardwellth_ID.classList.add('hide');
        Info_cardwellth_ID.classList.add('hide');
        cardwellth_Expand_ID.classList.remove('hide');

        // Hide session heading
        const headingEl = document.getElementById('session-heading-wrapper');
        if (headingEl) headingEl.classList.add('hide');

        // Enable buttons
        Info_actions_button1.disabled = false;
        Info_actions_button2.disabled = false;

        // Populate booking panel with selected service
        if (selectedService) {
          populateBookingPanel(selectedService);
          populateInfoPanel(selectedService);
        }

        // If clicked from detail card, hide detail card and show service list
        if (detailAddBtn) {
          document.getElementById('detail-card').style.display = 'none';
          document.querySelector('.session-list').style.display = 'block';
        }
      } else {
        // Hide panel #2, show panel #1 (toggle back)
        cardwellth_Expand_ID.classList.add('hide');
        cardwellth_ID.classList.remove('hide');
        Info_cardwellth_ID.classList.remove('hide');

        // Show session heading again
        const headingEl = document.getElementById('session-heading-wrapper');
        if (headingEl) headingEl.classList.remove('hide');

        // Disable buttons
        Info_actions_button1.disabled = true;
        Info_actions_button2.disabled = true;
      }
    }
  });
  //////////////////////////////////////////// booking ///////////////////////////////////////


  function populateBookingPanel(service) {
    const expandPanel = document.getElementById('cardwellth_Expand_ID');

    expandPanel.querySelector('h5').textContent = service.service_name || '';

    const priceEl = expandPanel.querySelectorAll('.slot-info strong')[0];
    if (priceEl) {
      priceEl.textContent = `${service.vendor?.currency || "$"} ${service.prices || "0.00"}`;
    }

    const durationEl = expandPanel.querySelectorAll('.slot-info span')[0];
    if (durationEl) {
      durationEl.textContent = `${(service.durations || []).join(' Min, ') || 'N/A'} Mins`;
    }

    // ✅ Just show expanded panel — don’t hide anything else
    expandPanel.classList.remove('hide');

    // Enable booking buttons
    Info_actions_button1.disabled = true;
    Info_actions_button2.disabled = false;


    // Hide detail view if coming from detail card
    document.getElementById('detail-card').style.display = 'none';
  }


  ///////////////////////////////////////////////////// Info Panel ////////////////////////////////


  function populateInfoPanel(service) {
    const infoPanel = document.getElementById('Info_cardwellth_ID');

    if (!service || !infoPanel) return;

    // Set name
    const titleEl = infoPanel.querySelector('h3');
    if (titleEl) {
      titleEl.textContent = service.vendor?.name || 'Business Name';
    }

    // Set location
    const locationEl = infoPanel.querySelectorAll('small')[0];
    if (locationEl) {
      locationEl.textContent = `${service.city[0].name || "N/A"},${service.countries[0].name || "N/A"}'`;
    }

    // Set operating hours
    const hoursEl = infoPanel.querySelectorAll('small')[1];
    if (hoursEl) {
      hoursEl.textContent = service.vendor?.timing || '9AM–10PM, Mon–Sun';
    }

    // Set rating
    const ratingSpan = infoPanel.querySelector('span.fw-semibold');
    const reviewsEl = infoPanel.querySelectorAll('small')[2];
    if (ratingSpan) {
      ratingSpan.textContent = service.vendor?.rating || '5.0';
    }
    if (reviewsEl) {
      reviewsEl.textContent = `(${service.vendor?.reviews_count || 0})`;
    }
  }



  document.getElementById('detail-card').addEventListener('click', function (e) {
    if (e.target.classList.contains('read-less')) {
      this.style.display = 'none';
      document.querySelector('.session-list').style.display = 'block';
    }
  });

  ////////////////////////////////////////////// populate more content  about//////////////////

  function populateMoreContent(service) {
    const moreContent = document.querySelector('#moreContent');
    if (!moreContent) {
      console.warn('Missing #moreContent container in the DOM.');
      return;
    }

    // Populate About section
    const aboutSection = moreContent.querySelector('.section p');
    if (aboutSection) {
      const aboutText = service.vendor?.description || "No description available.";
      aboutSection.innerHTML = aboutText;
    }

    // Populate Map
    const address = service.vendor?.address || "Unknown location";
    const mapSection = moreContent.querySelector('#map');
    const mapWrapper = mapSection?.parentElement;
    const locationLink = mapWrapper?.querySelector('p a');

    if (mapSection && mapWrapper && locationLink) {
      if (service.vendor?.location?.lat && service.vendor?.location?.lng) {
        const { lat, lng } = service.vendor.location;
        const mapIframe = document.createElement('iframe');
        mapIframe.src = `https://www.google.com/maps?q=${lat},${lng}&z=15&output=embed`;
        mapIframe.width = "100%";
        mapIframe.height = "300";
        mapIframe.style.border = "0";
        mapSection.innerHTML = ''; // Clear placeholder
        mapSection.appendChild(mapIframe);
        locationLink.href = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
      } else {
        mapSection.innerHTML = `<span>Map not available for this location.</span>`;
        locationLink.href = "#";
      }
      locationLink.textContent = "Get directions";
      mapWrapper.querySelector('p').textContent = `${address} `;
      mapWrapper.querySelector('p').appendChild(locationLink);
    }

    // Populate Opening Times
    const openingTimesBlock = moreContent.querySelector('.opening-times');
    if (openingTimesBlock) {
      openingTimesBlock.innerHTML = '';
      const hours = service.vendor?.business_hours || [];
      const days = service.vendor?.business_days || [];

      if (hours.length || days.length) {
        hours.forEach(hour => {
          const day = days[0] || "Open";
          const line = document.createElement('div');
          line.classList.add('fw-semibold');
          line.innerHTML = `🟢 ${day} <span>${hour.open} - ${hour.close}</span>`;
          openingTimesBlock.appendChild(line);
        });
      } else {
        openingTimesBlock.innerHTML = '<p>No opening times available.</p>';
      }
    }

    // Populate Additional Info
    const infoBlock = moreContent.querySelector('.additional-info');
    if (infoBlock) {
      infoBlock.innerHTML = '';
      const infos = service.vendor?.additional_info || [];
      if (infos.length) {
        infos.forEach(info => {
          const p = document.createElement('p');
          p.innerHTML = `<i class="bi bi-check2 me-2 fw-semibold"></i>${info}`;
          infoBlock.appendChild(p);
        });
      } else {
        infoBlock.innerHTML = '<p>No additional information available.</p>';
      }
    }
  }



  // grab references
  const cardwellth_ID = document.getElementById('cardwellth_ID');
  const cardwellth_Expand_ID = document.getElementById('cardwellth_Expand_ID');
  const Info_cardwellth_ID = document.getElementById('Info_cardwellth_ID');
  const Info_actions_button1 = document.getElementById('Info_actions_button1');
  const Info_actions_button2 = document.getElementById('Info_actions_button2');



  function renderCardsByType(data, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = ""; // Clear existing content

    if (!Array.isArray(data) || data.length === 0) {
      container.innerHTML = `
      <div class="text-center text-muted py-3">
        <p>No services available in this service type.</p>
      </div>
    `;
      return;
    }

    data.forEach(service => {
      const cardHTML = generateSessionCard(service);
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = cardHTML;
      container.appendChild(tempDiv.firstElementChild);
    });
  }






  $(document).ready(function () {
    // Category picker
    $(".time-picker").select2({
      placeholder: "Select a time",
      allowClear: true,
    });
  });

});


