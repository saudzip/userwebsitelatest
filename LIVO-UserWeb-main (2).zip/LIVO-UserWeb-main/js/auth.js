
//   function showLogin() {
//     document.getElementById("loginModal").style.display = "block";
//     document.getElementById("signupModal").style.display = "none";
//   }

//   function showSignup() {
//     document.getElementById("signupModal").style.display = "block";
//     document.getElementById("loginModal").style.display = "none";
//   }

//   function handleSignup() {
//     const user = document.getElementById("signupUser").value;
//     const pass = document.getElementById("signupPass").value;
//     localStorage.setItem("user_" + user, pass);
//     alert("Signup successful! Now log in.");
//     showLogin();
//   }

//   function handleLogin() {
//     const user = document.getElementById("loginUser").value;
//     const pass = document.getElementById("loginPass").value;
//     const stored = localStorage.getItem("user_" + user);

//     if (stored && stored === pass) {
//       localStorage.setItem("loggedInUser", user);
//       alert("Logged in!");
//       location.reload();
//     } else {
//       alert("Invalid credentials");
//     }
//   }

//   function isLoggedIn() {
//     return !!localStorage.getItem("loggedInUser");
//   }

//   function useFeature() {
//     if (!isLoggedIn()) {
//       alert("You must log in or sign up to use this feature.");
//       showLogin();
//       return;
//     }

//     alert("Using protected feature!");
//   }

//   // 🧠 Auto-run on page load
//   document.addEventListener("DOMContentLoaded", () => {
//     if (!isLoggedIn()) {
//       showLogin();
//     } else {
//       alert("Welcome back, " + localStorage.getItem("loggedInUser") + "!");
//     }
//   });




document.addEventListener('DOMContentLoaded', function () {
  if (!localStorage.getItem('loggedInUser')) {
    // Show signup modal automatically
    const signupModal = new bootstrap.Modal(document.getElementById('welcomeModal'), {
    //   backdrop: 'static',  // disables clicking outside to close
    //   keyboard: false      // disables ESC key to close
    });
    signupModal.show();
  }
});

