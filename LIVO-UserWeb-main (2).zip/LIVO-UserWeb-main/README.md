# Livo User Web Frontend 

A responsive, Bootstrap‑based front‑end prototype for the **Wellth** longevity & biohacking brand.

---


## ⚙️ Installation & Setup

1. **Clone the repository**  
   ```bash
   git clone https://github.com/Muhammad-waqas1/LIVO-Web-Frontend.git

2. **Serve locally**You can simply open index.html in your browser, or use a simple HTTP server:

    _Visit [http://localhost:8080](http://localhost:8080)._


**Dependencies**

*   [Bootstrap 5.3](https://getbootstrap.com/)
    
*   No build tool or package manager required—pure HTML/CSS/JS.



🎨 Customization
----------------

*   **Colors & Typography**Edit CSS variables (in css/styles.css) to match your brand palette or type scale.
    
*   **Icons & Images**Swap under assets/icons/ and assets/images/. Maintain original file names or update HTML references.
    
*   **Session Data**The session cards are hard‑coded in index.html. For dynamic data, replace with your templating or API integration.






> Contact: For questions or styling guidance [open an issue](https://github.com/Muhammad-waqas1/LIVO-Web-Frontend/issues) in this repo.
