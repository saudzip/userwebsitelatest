// example: toggle category selection
document.querySelectorAll('.cat-item').forEach(el => {
    el.addEventListener('click', () => {
        document.querySelector('.cat-item.selected')?.classList.remove('selected');
        el.classList.add('selected');
    });
});




(function () {
    const avatarBtn = document.getElementById('avatarBtn');
    const avatarWrapper = document.querySelector('.avatar-dropdown');

    // 1) Toggle on avatar click
    avatarBtn.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        // remove any stubborn inline display from the other script
        avatarWrapper.querySelector('.dropdown-menu').style.display = '';
        avatarWrapper.classList.toggle('show-menu');
    });


    // 2) Click anywhere else on document → close if click is outside the wrapper
    document.addEventListener('click', e => {
        if (!avatarWrapper.contains(e.target)) {
            avatarWrapper.classList.remove('show-menu');
        }
    });

    // 3) Hit Esc to close
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape') {
            avatarWrapper.classList.remove('show-menu');
        }
    });
})();









document.addEventListener("DOMContentLoaded", function () {
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
        initialCountry: "ae",
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js"
    });
});
