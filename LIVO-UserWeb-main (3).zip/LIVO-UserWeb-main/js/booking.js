let allBookings;
document.addEventListener("DOMContentLoaded", () => {
  const tabMapping = {
    toBook: "toBook-container",
    upcoming: "upcoming-container",
    completed: "completed-container",
    cancelled: "cancelled-container",
  };

  // Map tabs to their corresponding status values
  const statusMapping = {
    toBook: "pending",
    upcoming: "book later",
    completed: "approved", 
    cancelled: "cancelled"
  };

  async function fetchBookings(page, tab) {
    let url = `http://100.27.227.121:8000/api/booking?page=${page}`;
    if (tab && statusMapping[tab]) {
      url += `&status=${statusMapping[tab]}`;
    }
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Error fetching ${tab} page ${page}`);
      console.log(`Fetching bookings for tab: ${tab}, page: ${page}, status: ${statusMapping[tab]}`);
      const data = await response.json();
      console.log(`Fetched data for tab: ${tab}`, data.result.data);
      allBookings = data.result.data;
      return data;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  console.log("Booking script loaded", allBookings);

  async function loadTab(tabId) {
    const containerId = tabMapping[tabId];
    const bookingsData = await fetchBookings(1, tabId);
    if (bookingsData && bookingsData.result && bookingsData.result.data) {
      renderCards(bookingsData.result.data, containerId, tabId);
    } else {
      document.getElementById(containerId).innerHTML = "<p>Error loading bookings.</p>";
    }
  }

  // Attach event listeners to each tab button
  document.querySelectorAll(".nav-link").forEach((tabBtn) => {
    tabBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      const tabId = e.target.id.replace("-tab", "");
      await loadTab(tabId);
    });
  });

  // Load default tab (toBook)
  loadTab("toBook");
});

// Render cards in the container
function renderCards(bookings, containerId, tab) {
  const container = document.getElementById(containerId);
  container.innerHTML = "";

  if (bookings.length === 0) {
    container.innerHTML = "<p>No bookings found.</p>";
    return;
  }

  bookings.forEach((booking, index) => {
    const card = createCard(booking, tab, index);
    container.appendChild(card);
  });
}

// Create individual card element based on booking data and tab
function createCard(booking, tab, index) {
  const card = document.createElement("div");
  card.className = "facility-card";

  // Image container
  const imageDiv = document.createElement("div");
  imageDiv.className = tab === "cancelled" ? "facility-card__image_cancel" : "facility-card__image";

  const img = document.createElement("img");
  img.src = booking.image_url || "assets/images/facilities0.png";
  img.alt = booking.facility_name || "Facility Image";
  imageDiv.appendChild(img);

  // Content container
  const contentDiv = document.createElement("div");
  contentDiv.className = tab === "cancelled" ? "facility-card__content_cancel" : "facility-card__content";

  // Inner content block (title, subtitle, text)
  const innerContent = document.createElement("div");
  if (tab !== "cancelled") innerContent.className = "pe-4"; // padding end only for non-cancelled

  // Title with optional "Cancelled" tag
  const title = document.createElement("h2");
  title.className = "facility-card__title";
  title.textContent = booking.facility_name || "Facility Name";

  if (tab === "cancelled") {
    const cancelledSpan = document.createElement("span");
    cancelledSpan.className = "Cancelled_info";
    cancelledSpan.textContent = "Cancelled";
    title.appendChild(cancelledSpan);
  }

  // Subtitle (address and service)
  const subtitle = document.createElement("p");
  subtitle.className = "facility-card__subtitle";
  if (tab === "cancelled") subtitle.classList.add("mb-4");

  if (booking.address || booking.service_name) {
    // For cancelled and others, address and service might be on separate lines
    subtitle.innerHTML = 
      (booking.address ? `<small>${booking.address}</small><br>` : "") +
      (booking.service_name ? `<small>${booking.service_name}</small>` : "");
  }

  // Text (date/time or service description)
  const text = document.createElement("p");
  text.className = "facility-card__text";
  if (tab === "toBook") {
    text.textContent = booking.service_name || "Service";
  } else {
    // Use date and time info
    if (booking.datetime) {
      text.textContent = booking.datetime;
    } else {
      // fallback
      text.textContent = "";
    }
  }

  innerContent.appendChild(title);
  innerContent.appendChild(subtitle);
  innerContent.appendChild(text);

  contentDiv.appendChild(innerContent);

  // Buttons section (only if not cancelled)
  if (tab !== "cancelled") {
    const btnsDiv = document.createElement("div");
    btnsDiv.className = "d-flex justify-content-between align-items-center gap-2";

    // Main button text depends on tab
    const mainBtn = document.createElement("a");
    mainBtn.className = "facility-card__btn";
    mainBtn.href = "#";

    switch (tab) {
      case "toBook":
        mainBtn.textContent = booking.status || "Pending";
        break;
      case "upcoming":
        mainBtn.textContent = "ReBook";
        break;
      case "completed":
        mainBtn.textContent = "Booked";
        break;
    }

    btnsDiv.appendChild(mainBtn);

    // Delete button for upcoming and completed
    if (tab === "upcoming" || tab === "completed") {
      const deleteBtn = document.createElement("button");
      deleteBtn.className = "btn btn-delete";
      deleteBtn.setAttribute("data-bs-toggle", "modal");
      deleteBtn.setAttribute("data-bs-target", "#cancelModal");

      const binImg = document.createElement("img");
      binImg.src = "assets/images/bin.png";
      binImg.alt = "delete";

      deleteBtn.appendChild(binImg);
      btnsDiv.appendChild(deleteBtn);
    }

    contentDiv.appendChild(btnsDiv);
  }

  card.appendChild(imageDiv);
  card.appendChild(contentDiv);

  return card;
}