const base_url = "http://100.27.227.121:8000/api";
let fetchedServices;
let fetchedVendors;
let currentPage = 1;
const servicesPerPage = 10;

// Function to limit description to 10 words
function limitDescription(description, charLimit) {
  if (description.length > charLimit) {
    return description.slice(0, charLimit) + "...";
  }
  return description;
}

async function getServices() {
  const fetchedServices = [];
  const fetchedVendors = [];

  try {
    // Fetch all pages of services
    let servicePage = 1;
    let serviceLastPage = 1;

    do {
      const serviceRes = await fetch(
        `${base_url}/services?page=${servicePage}`
      );

      if (!serviceRes.ok)
        throw new Error(`Service fetch failed: ${serviceRes.status}`);
      const serviceJson = await serviceRes.json();
      console.log("serviceRes", serviceJson);

      fetchedServices.push(...serviceJson.data.data);
      serviceLastPage = serviceJson.data.last_page;
      servicePage++;
    } while (servicePage <= serviceLastPage);

    // Fetch all pages of vendors
    let vendorPage = 1;
    let vendorLastPage = 1;

    do {
      const vendorRes = await fetch(`${base_url}/vendors?page=${vendorPage}`);
      if (!vendorRes.ok)
        throw new Error(`Vendor fetch failed: ${vendorRes.status}`);
      const vendorJson = await vendorRes.json();
      console.log("vendorRes", vendorJson);

      fetchedVendors.push(...vendorJson.vendors.data);
      vendorLastPage = vendorJson.vendors.last_page;
      vendorPage++;
    } while (vendorPage <= vendorLastPage);

    console.log("All Services:", fetchedServices);
    console.log("All Vendors:", fetchedVendors);

    createServiceCards(fetchedServices);
    createVendorCards(fetchedVendors);

    return { services: fetchedServices, vendors: fetchedVendors };
  } catch (error) {
    console.error("Fetch error:", error.message);
    return null;
  }
}

function createServiceCards(services, page = 1) {
  const container = document.getElementById("ApiServices");
  container.innerHTML = "";
  const rating = services.rating || "0.0";
    const reviewCount = services.reviews_count || "0";

  services.forEach((service, index) => {
    const wrapperDiv = document.createElement("div");

    const serviceImage =
      service.images.length > 0
        ? `${service.images?.[0].image_path}`
        : "assets/images/service1.jpg";

    wrapperDiv.innerHTML = `
      <div class="card custom-card mx-auto" data-index="${index}">
        <div class="position-relative">
          <a href="wellth.html" class="see-more-link">
           <img
            src="${serviceImage}"
            onerror="this.onerror=null;this.src='assets/images/service1.jpg';"
            class="card-img-top_custom"
            alt="${service.service_name || "Service Image"}"
          />
          </a>
          <button class="btn btn-light btn-sm favorite-btn">
            <a href="favourite.html" style="text-decoration: none; color:black"><i class="bi bi-heart"></i></a>
          </button>
        </div>

        <div class="card-body" style="max-height:326px;" id="service-cards">
          <a href="Wellth.html" class="see-more-link card-title mb-1">
            ${service.vendor.name || "N/A"}
          </a>

          <div class="d-flex justify-content-between align-items-center mb-1">
            <p style="font-size: 12px" class="text-muted mb-2">
              <i class="bi bi-geo-alt-fill me-1"></i>
             ${service.city[0].name},${service.countries[0].name}

            </p>
            <p class="mb-2">
              <i class="bi bi-star-fill text-warning"></i>
              <span class="fw-bold">${rating}</span>
              <small class="text-muted">(${reviewCount})</small>
            </p>
          </div>

          <div class="d-flex align-items-center justify-content-between  mb-1">
          <div>
           ${service.vendor.business_hours
             .map(
               (item, index) =>
                 `
            <span key=${index} style="font-size: 12px" class="text-muted mb-2">
             <i class="bi bi-clock me-1"></i> ${item.open}-${item.close}
            </span>`
             )
             .join("")}
           ${service.vendor.business_days
             .map(
               (item, index) =>
                 `
            <span key=${index} style="font-size: 12px" class="text-muted mb-2">
            , ${
              service.vendor.business_days.length == 1
                ? item[0].substring(0, 3)
                : `${item[0].substring(0, 3)}-${item[item.length - 1].substring(
                    0,
                    3
                  )}`
            }
            </span>`
             )
             .join(",")}

          </div>
            <div class="avatar-group ms-3">
              <img src="assets/images/avatar.png" alt="" class="avatar" />
              <img src="assets/images/avatar1.jpg" alt="" class="avatar" />
              <img src="assets/images/avatar.png" alt="" class="avatar" />
            </div>

          </div>

          <div class="service-pill p-3 mb-2 mt-2 position-relative">
  <div class="d-flex flex-wrap justify-content-between align-items-start">
    <div > <!-- reserve space for button -->
      <h6 class="mb-1">${service.service_name}</h6>
      <p class="text-muted mb-1" style="font-size: 12px">
        ${limitDescription(service.service_description, 25)}
        <a href="Wellth.html" class="read-more-link fw-bold text-dark text-muted text-decoration-none" data-index="${index}">
    read more
</a>
      </p>

        <div style="display:flex; align-items:center; justify-content:space-between">
        <div style="display:flex; align-items:center">
        <span class="text-muted">${service.prices || "N/A"}</span>
        <span class="text-muted">${service.vendor.currency || "N/A"}</span>,
        <span class="ms-1"> <i class="bi bi-clock me-1"></i>${
          Array.isArray(service.durations) && service.durations.length
            ? service.durations.join(" Min, ") + " Mins"
            : "N/A"
        }
        </span>
        </div>
        </div>

  <div style="display: flex; align-items: center; justify-content: space-between;">
  
  <!-- Location Types -->
  <div>
    <small class="text-muted me-auto">
      ${
        service.service_types
      },<img src="assets/icons/location.svg" alt="icon" width="17px" style="margin-right: -3px;"> ${
      Array.isArray(service.location_types) && service.location_types.length
        ? service.location_types.join(", ")
        : "N/A"
    }
    </small>
  </div>


</div>

    </div>

    <!-- Fixed position button -->
    <button class="btn-add button_extend position-absolute">
      <img src="assets/icons/Add_Icon_Wellth.png" alt="icon" class="img-fluid" />
    </button>
  </div>
</div>

          <div class="see-more-container text-center mb-2">
            <a href="Wellth.html" class="text-decoration-none fw-semibold see-more-link">See more</a>
          </div>

          <div class="service-details d-none mb-2">
            <h6>Unlock Peak Performance and Longevity</h6>
            <p class="text-muted">Choose the membership plan that suits your goals.</p>
            <div style="display: flex; gap: 7%">
              <span>$1000</span>
              <span><i class="bi bi-clock me-1"></i>Monthly</span>
            </div>
            <h6 class="mt-3">Benefits</h6>
            <p class="mb-0 text-muted">${service.service_benefits || "N/A"}</p>
            <div class="actions mt-3">
              <button class="btn button_extend btn-primary">Add</button>
              <button class="btn btn-outline-secondary">
                <svg xmlns="http://www.w3.org/2000/svg" width="27" height="20" viewBox="0 0 30 22" fill="none">
                  <path d="M1.35156 8.18659C1.35156 13.8782 6.93721 16.9113 11.026 19.6261C12.4688 20.5841 13.8585 21.486 15.2482 21.486C16.6378 21.486 18.0275 20.5841 19.4704 19.6261C23.5592 16.9113 29.1448 13.8782 29.1448 8.18659C29.1448 2.49488 21.5014 -1.54156 15.2482 3.93037C8.99492 -1.54156 1.35156 2.49488 1.35156 8.18659Z" fill="#355350" stroke="#355350" stroke-width="0.950495"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // See more card link
    wrapperDiv.querySelectorAll(".see-more-link").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();

        const card = e.currentTarget.closest(".card");
        const serviceIndex = card?.dataset.index;
        if (serviceIndex === undefined) return;

        const selectedService = {
          ...services[serviceIndex],
          vendors: fetchedVendors,
        };

        localStorage.setItem("moreServices", JSON.stringify(selectedService));
        window.location.href = "Wellth.html";
      });
    });
     wrapperDiv.querySelectorAll(".read-more-link").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();

        const card = e.currentTarget.closest(".card");
        const serviceIndex = card?.dataset.index;
        if (serviceIndex === undefined) return;

        const selectedService = {
          ...services[serviceIndex],
          vendors: fetchedVendors,
        };

        localStorage.setItem("moreServices", JSON.stringify(selectedService));
        window.open("Wellth.html", "_blank");
      });
    });
    container.appendChild(wrapperDiv);
  });

  // Expanded Panel Button Handler
  document.querySelectorAll(".button_extend").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const card = btn.closest(".card");
      const serviceIndex = card?.dataset.index;
      const service = services[serviceIndex];
      if (service) {
        populateExpandedPanel(service);
      }

      const cardwellth = document.querySelector(".cardwellth");
      const panel = document.querySelector(".expanded-panel");
      if (cardwellth && panel) {
        cardwellth.style.display = "block";
        panel.classList.add("open");
      }
    });
  });

  // See more toggle
  document.querySelectorAll(".see-more-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const card = btn.closest(".card");
      const details = card.querySelector(".service-details");
      const pill = card.querySelector(".service-pill");
      const seeMore = card.querySelector(".see-more-container");

      if (details && pill && seeMore) {
        const isHidden = details.classList.contains("d-none");
        details.classList.toggle("d-none", !isHidden);
        pill.style.display = isHidden ? "none" : "block";
        seeMore.style.display = isHidden ? "none" : "block";
      }
    });
  });

  // Hide details when clicking outside
  document.addEventListener("click", (e) => {
    if (e.target.closest(".see-more-btn")) return;

    document.querySelectorAll(".card").forEach((card) => {
      const details = card.querySelector(".service-details");
      const pill = card.querySelector(".service-pill");
      const seeMore = card.querySelector(".see-more-container");

      if (details && pill && seeMore) {
        details.classList.add("d-none");
        pill.style.display = "block";
        seeMore.style.display = "block";
      }
    });
  });
}

function createVendorCards(vendors) {
  const container = document.getElementById("ApiVendors");
  container.innerHTML = "";

  vendors.forEach((vendor, index) => {
    const wrapperDiv = document.createElement("div");

    // Safe fallback values
    const name = vendor.name || "Unknown Facility";
    const location =
      (vendor.cities?.[0]?.name || "Unknown City") +
      ", " +
      (vendor.countries?.[0]?.name || "Unknown Country");
    const rating = vendor.rating || "0.0";
    const reviewCount = vendor.reviews_count || "0";
    const description = vendor.description || "No description available.";
    const logoUrl = `http://100.27.227.121/logo/${vendor.logo}`;

    wrapperDiv.innerHTML = `
      <div class="card h-100 custom-card_facility shadow-sm" data-index="${index}">
        <div class="position-relative">
          <a href="Wellth.html" class="vendor-link">
            <img src="${logoUrl}" class="card-img_facility" alt="${name}" />
          </a>
          <button class="btn btn-light btn-sm favorite-btn">
            <a href="favourite.html" style="text-decoration: none; color:black"><i class="bi bi-heart"></i></a>
          </button>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <a href="Wellth.html" class="card-title mb-1 vendor-link">${name}</a>
            <p class="mb-2">
              <i class="bi bi-star-fill text-warning"></i>
              <span class="fw-bold">${rating}</span>
              <small class="text-muted">(${reviewCount})</small>
            </p>
          </div>
          <p class="text-muted fw-medium mb-2">
            <i class="bi bi-geo-alt-fill"></i> ${location}
          </p>
          <p class="mb-0" style="color: #6e6a6a">${description}</p>
        </div>
      </div>
    `;

    // Append to container
    container.appendChild(wrapperDiv);

    // Add event listener to vendor link(s)
    const links = wrapperDiv.querySelectorAll(".vendor-link");
    links.forEach((link) => {
      link.addEventListener("click", () => {
        localStorage.setItem("vendorData", JSON.stringify(vendor));
      });
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  getServices();
  getCategories();

  const panel = document.querySelector(".expanded-panel");
  const cardwellth = document.querySelector(".cardwellth");
  const bookLaterBtn = panel?.querySelector(".book-later-btn");

  document.addEventListener("click", (e) => {
    if (panel && !panel.contains(e.target)) {
      cardwellth && (cardwellth.style.display = "none");
      panel.classList.remove("open");
    }
  });

  bookLaterBtn?.addEventListener("click", (e) => {
    e.stopPropagation();
    cardwellth && (cardwellth.style.display = "none");
    panel.classList.remove("open");
  });

  // Date pills
  document.querySelectorAll(".date-pill").forEach((pill) => {
    pill.addEventListener("click", () => {
      document
        .querySelectorAll(".date-pill")
        .forEach((d) => d.classList.remove("selected"));
      if (!pill.classList.contains("more")) {
        pill.classList.add("selected");
        updateBookNowState(wrapperDiv);
      }
    });
  });

  // Time slots
  document.querySelectorAll(".time-slot").forEach((slot) => {
    slot.addEventListener("click", () => {
      document
        .querySelectorAll(".time-slot")
        .forEach((s) => s.classList.remove("selected"));
      slot.classList.add("selected");
      updateBookNowState(wrapperDiv);
    });
  });
});
///////////////////////////////////////////////////// Populate Expanded Panel /////////////////////////////////////////////////////

function formatTimeSlot(open, close) {
  return `
    <div class="time-slot" data-slot="${open}–${close}">
      <div class="slot-info">
        <img src="assets/icons/clock.svg" alt="" />
        <span>${open} – ${close}</span>
      </div>
    </div>`;
}

function generateTimeSlotsHTML(service) {
  if (!service) {
    console.error("Service is undefined:", service);
    return "";
  }
  const businessHours = service.vendor.business_hours;

  let slotsHTML = "";

  businessHours.forEach((hour) => {
    if (businessHours.length > 0) {
      slotsHTML += formatTimeSlot(hour.open, hour.close);
    } else {
      slotsHTML += `<p>No Business Hours Available</p>`;
    }
  });

  return slotsHTML;
}

function updateBookNowState(wrapper) {
  const dateSelected = wrapper.querySelector(".date-pill.selected")?.dataset
    .day;
  const timeSelected = wrapper.querySelector(".time-slot.selected")?.dataset
    .slot;
  const bookNowBtn = wrapper.querySelector("#bookNow");

  if (dateSelected && timeSelected) {
    bookNowBtn.disabled = false;
  } else {
    bookNowBtn.disabled = true;
  }
}

function populateExpandedPanel(service) {
  const panel = document.getElementById("cardwellth_home_ID");
  panel.innerHTML = "";
  const wrapperDiv = document.createElement("div");

  const price = service.prices ?? "N/A";
  const currency = service.vendor.currency ?? "N/A";
  const duration = service.durations.join("Min, ") ?? "N/A";
  const title = service.service_name ?? "Service";

  wrapperDiv.innerHTML = `
    <div class="expanded-panel toggle-div" id="expanded-panel_home_ID">
        <h5>${title}</h5>
        <div class="meta-row">
          <div class="slot-info">
            <strong>${price}</strong>
            <span>${currency}</span>
          </div>
          <div class="slot-info">
            <img src="assets/icons/clock.svg" alt="Clock" />
            <span>${duration}Mins</span>
          </div>
          <button class="btn-add" fdprocessedid="dguv8q">
            <img src="assets/icons/Arrow_bottom.svg" />
          </button>
        </div>

        <!-- Date selector -->
<div class="section-label">Select Date</div>
<div class="date-selector" id="dynamic-date-pills">
  <!-- Date pills will be injected here -->
</div>


          <!-- Hidden native picker (must be outside the pill) -->
          <input
            type="text"
            id="custom-date-input"
            style="display: none"
            class="flatpickr-input"
            readonly="readonly"
          />
        </div>

          <!-- Time slots -->
    <div class="section-label">Select Time</div>
    <div class="time-list" id="time-slots-list" >
      ${generateTimeSlotsHTML(service)}
    </div>
        <div class="Info_actions">
          <button id="bookNow"   class="btn  continue-btn" disabled>Book Now</button>
          <button id="bookLater" class="btn book-later-btn">Book Later</button>
        </div>
      </div>
  `;

  //generate dates
  const dateSelector = wrapperDiv.querySelector("#dynamic-date-pills");
  const today = new Date();

  for (let i = 0; i < 3; i++) {
    const currentDate = new Date(today);
    currentDate.setDate(today.getDate() + i);

    const weekday = currentDate
      .toLocaleDateString("en-US", { weekday: "short" })
      .toUpperCase();
    const month = currentDate.toLocaleDateString("en-US", { month: "short" });
    const day = currentDate.getDate().toString().padStart(2, "0");

    const pillDiv = document.createElement("div");
    pillDiv.className = "date-pill";
    pillDiv.dataset.day = `${weekday} ${month} ${day}`;
    pillDiv.innerHTML = `
    <div class="day">${weekday}</div>
    <small>${month} ${day}</small>
  `;

    dateSelector.appendChild(pillDiv);
  }

  const customPill = document.createElement("div");
  customPill.className = "date-pill more";
  customPill.id = "custom-date-pill";
  customPill.innerHTML = `<img src="assets/icons/calendar.svg" alt="More" />`;

  dateSelector.appendChild(customPill);

  // Also append the hidden input (must come after the custom pill)
  const customInput = document.createElement("input");
  customInput.type = "text";
  customInput.id = "custom-date-input";
  customInput.style.display = "none";
  customInput.className = "flatpickr-input";
  customInput.readOnly = true;

  dateSelector.appendChild(customInput);

  // Date pill selection
  wrapperDiv.querySelectorAll(".date-pill").forEach((pill) => {
    pill.addEventListener("click", () => {
      wrapperDiv
        .querySelectorAll(".date-pill")
        .forEach((d) => d.classList.remove("selected"));
      if (!pill.classList.contains("more")) {
        pill.classList.add("selected");
        updateBookNowState(wrapperDiv);
      }
    });
  });

  // Time slot selection
  wrapperDiv.querySelectorAll(".time-slot").forEach((slot) => {
    slot.addEventListener("click", () => {
      wrapperDiv
        .querySelectorAll(".time-slot")
        .forEach((s) => s.classList.remove("selected"));
      slot.classList.add("selected");
      updateBookNowState(wrapperDiv);
    });
  });

  // Flatpickr
  const pill = wrapperDiv.querySelector("#custom-date-pill");
  const picker = wrapperDiv.querySelector("#custom-date-input");

  console.log("picker", picker);
  console.log("pill", pill);

  if (picker && pill) {
    console.log("come inside date picker");
    flatpickr(picker, {
      defaultDate: null,
      allowInput: false,
      clickOpens: false,
      minDate: "today", // ✅ This disables all dates before today
      onChange: function (selectedDates, dateStr) {
        if (!dateStr) return;
        const dt = selectedDates[0];
        const weekday = dt
          .toLocaleDateString("en-US", { weekday: "short" })
          .toUpperCase();
        const month = dt.toLocaleDateString("en-US", { month: "short" });
        const dayNum = dt.getDate().toString().padStart(2, "0");

        pill.dataset.day = `${weekday} ${month} ${dayNum}`;
        pill.innerHTML = `
      <div class="day">${weekday}</div>
      <small>${month} ${dayNum}</small>
    `;
        pill.classList.add("selected");
        updateBookNowState(wrapperDiv); // ✅ Make sure to update the state
      },
      onReady: function (_, __, fp) {
        const calendar = fp.calendarContainer;
        calendar.classList.add("flatpickr-calendar");
      },
    });

    pill.addEventListener("click", () => {
      const isOpen = picker._flatpickr.isOpen;
      if (isOpen) picker._flatpickr.close();
      else picker._flatpickr.open();
    });
  }

  wrapperDiv.querySelector("#bookNow").addEventListener("click", (e) => {
    e.preventDefault();

    // Get selected date
    const selectedDatePill = wrapperDiv.querySelector(".date-pill.selected");
    const selectedDate = selectedDatePill ? selectedDatePill.dataset.day : null;

    // Get selected time slot
    const selectedTimeSlot = wrapperDiv.querySelector(".time-slot.selected");
    const timeSlot = selectedTimeSlot ? selectedTimeSlot.dataset.slot : null;

    // Combine everything into a single object
    const payload = {
      bookType: "bookNow",
      service,
      selectedDate,
      timeSlot,
    };

    console.log("Payload:", payload);
    // Save to localStorage
    localStorage.setItem("selectedBookingData", JSON.stringify(payload));

    // Navigate to service.html
    window.location.href = "service.html";
  });

  wrapperDiv.querySelector("#bookLater").addEventListener("click", (e) => {
    e.preventDefault();

    // Get selected date
    // const selectedDatePill = wrapperDiv.querySelector(".date-pill.selected");
    // const selectedDate = selectedDatePill ? selectedDatePill.dataset.day : null;

    // Get selected time slot
    // const selectedTimeSlot = wrapperDiv.querySelector(".time-slot.selected");
    // const timeSlot = selectedTimeSlot ? selectedTimeSlot.dataset.slot : null;

    // Combine everything into a single object
    const payload = {
      bookType: "bookLater",
      service,
      selectedDate: "",
      timeSlot: "",
    };

    console.log("PayloadbookLater:", payload);
    // Save to localStorage
    localStorage.setItem("selectedBookingLaterData", JSON.stringify(payload));

    // Navigate to service.html
    window.location.href = "Review.html";
  });

  panel.appendChild(wrapperDiv);
}

///////////////////////////////////////////////////// Categories /////////////////////////////////////////////////////
function createCategoryCards(categories) {
  const container = document.getElementById("ApiCategories");

  if (!container) {
    console.error("Container element #ApiCategories not found in DOM");
    return;
  }

  container.innerHTML = "";

  categories.forEach((category, index) => {
    const wrapperDiv = document.createElement("div");
    const isSelected = index === 0;

    wrapperDiv.innerHTML = `
      <a href="#" class="cat-item ${isSelected ? "selected" : ""}">
        <img src="${category.icon || "assets/icons/Frame 3.svg"}" alt="${
      category.name
    }" />
        <span>${category.name}</span>
      </a>
    `;

    const anchor = wrapperDiv.querySelector("a");
    const img = wrapperDiv.querySelector("img");

    if (isSelected) {
      img.style.backgroundColor = "rgb(255 203 203)";
      img.style.borderRadius = "8px";
      img.style.padding = "6px";
      getSubCategoriesByCategory(category.id);
    }

    anchor.addEventListener("click", async (e) => {
      e.preventDefault();

      document.querySelectorAll(".cat-item").forEach((item) => {
        item.classList.remove("selected");
        const itemImg = item.querySelector("img");
        if (itemImg) {
          itemImg.style.backgroundColor = "";
          itemImg.style.borderRadius = "";
        }
      });

      anchor.classList.add("selected");
      img.style.backgroundColor = "rgb(255 203 203)";
      img.style.borderRadius = "8px";
      img.style.padding = "6px";

      await getSubCategoriesByCategory(category.id);
    });

    container.appendChild(wrapperDiv);
  });
}

async function getCategories() {
  const allCategories = [];
  let currentPage = 1;
  let lastPage = 1; // Initialize lastPage, it will be updated by the API response

  try {
    do {
      const response = await fetch(
        `http://100.27.227.121:8000/api/categories?page=${currentPage}` // CORRECTED: Use currentPage here!
      );
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const pageData = data.result.data;
      lastPage = data.result.last_page; // Update lastPage from the response
      allCategories.push(...pageData);
      currentPage++; // Increment for the next iteration
    } while (currentPage <= lastPage); // Continue as long as there are more pages

    console.log("All Categories:", allCategories);
    createCategoryCards(allCategories);
    showAllDropDown(allCategories);
    return allCategories;
  } catch (error) {
    console.error("Fetch error:", error.message);
    return null;
  }
}

function showAllDropDown(categories) {
  const dropdownMenu = document.querySelector("#allCatDropDown .dropdown-menu");
  dropdownMenu.innerHTML = "";

  if (!dropdownMenu) {
    console.error("Dropdown menu not found!");
    return;
  }

  categories.forEach((category) => {
    const li = document.createElement("li");
    li.classList.add("dynamic-category");
    li.textContent = category.name;

    li.addEventListener("click", async () => {
      const btn = document.querySelector("#allCatDropDown .dropdown-toggle");
      btn.textContent = category.name;
      dropdownMenu.style.display = "none";
      await getSubCategoriesByCategory(category.id);
    });

    dropdownMenu.appendChild(li);
  });
}

function showAllSubCategoriesDropDown(subCategories) {
  const dropdownMenu = document.querySelector("#subCatDropDown .dropdown-menu");
  dropdownMenu.innerHTML = "";
  if (!dropdownMenu) {
    console.error("Dropdown menu not found!");
    return;
  }

  subCategories.forEach((category) => {
    const li = document.createElement("li");
    li.classList.add("dynamic-category");
    li.textContent = category.name;

    li.addEventListener("click", () => {
      const btn = document.querySelector("#subCatDropDown .dropdown-toggle");
      btn.textContent = category.name;
      dropdownMenu.style.display = "none";
    });

    // Insert before date input if exists, or at the end

    dropdownMenu.appendChild(li);
  });
}

async function getSubCategoriesByCategory(categoryId) {
  try {
    const response = await fetch(
      `${base_url}/categories/${categoryId}/sub-categories`
    );
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    console.log("SubCategoires:", data.result);
    const subCategories = data.result;
    showAllSubCategoriesDropDown(subCategories);
    return data;
  } catch (error) {
    console.error("Fetch error:", error.message);
    return null;
  }
}

////////////////////////////////////////////////////// Business Hours and Businees Days ///////////////////////////////
function renderPaginationControls(totalServices) {
  const paginationContainer = document.getElementById("PaginationControls");
  paginationContainer.innerHTML = "";

  const totalPages = Math.ceil(totalServices / servicesPerPage);

  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement("button");
    btn.className = `btn btn-sm mx-1 ${
      i === currentPage ? "btn-primary" : "btn-outline-primary"
    }`;
    btn.textContent = i;
    btn.addEventListener("click", () => {
      currentPage = i;
      createServiceCards(fetchedServices, fetchedVendors, currentPage);
    });
    paginationContainer.appendChild(btn);
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// grab all dropdown containers
const dropdowns = document.querySelectorAll(".dropdown");

// helper to close all menus
function closeAll() {
  document.querySelectorAll(".dropdown-menu").forEach((m) => {
    m.style.display = "none";
  });
}

$(document).ready(function () {
  // Category picker
  $(".time-picker").select2({
    placeholder: "Select a time",
    allowClear: true,
  });
});

dropdowns.forEach((drop) => {
  const btn = drop.querySelector(".dropdown-toggle");
  const menu = drop.querySelector(".dropdown-menu");
  const items = menu.querySelectorAll("li[data-value]");
  const dateInputLi = menu.querySelector(".date-input");
  const datePicker = menu.querySelector(".date-picker");

  // hide date-picker by default if it exists
  if (dateInputLi) dateInputLi.style.display = "none";

  // toggle this menu
  btn.addEventListener("click", (e) => {
    e.stopPropagation(); // prevent the global click‐handler
    closeAll(); // close any other open menus
    menu.style.display = menu.style.display === "block" ? "none" : "block";
    if (dateInputLi) dateInputLi.style.display = "none";
  });

  // pick an item
  items.forEach((item) => {
    item.addEventListener("click", (e) => {
      const val = item.dataset.value;

      if (val === "Date" && dateInputLi) {
        // show date picker
        dateInputLi.style.display = "block";
        datePicker.focus();
      } else {
        // set the button text & close
        btn.textContent = val;
        menu.style.display = "none";
      }
    });
  });

  // handle date select
  if (datePicker) {
    datePicker.addEventListener("change", () => {
      if (datePicker.value) {
        btn.textContent = datePicker.value;
        menu.style.display = "none";
      }
    });
  }
});

// anywhere else click => close all
document.addEventListener("click", () => {
  closeAll();
});

// filter Modal

const filterToggle = document.getElementById("filterToggle");
const filterModal = document.getElementById("filterModal");
const applyBtn = document.getElementById("applyBtn");

// Show modal on icon click
filterToggle.addEventListener("click", () => {
  filterModal.style.display = "flex";
});

// Hide modal when clicking outside the .modal-content
filterModal.addEventListener("click", (e) => {
  if (e.target === filterModal) {
    filterModal.style.display = "none";
  }
});

// Handle Apply
applyBtn.addEventListener("click", () => {
  const selected = document.querySelector('input[name="filter"]:checked').value;
  console.log("Selected filter:", selected);
  // ... do something with selected filter ...
  filterModal.style.display = "none";
});

const clearVendorDataIfOnIndex = () => {
  const currentPath = window.location.pathname;

  if (currentPath === "/" || currentPath.endsWith("/index.html")) {
    localStorage.removeItem("vendorData");
  }
};

window.addEventListener("load", clearVendorDataIfOnIndex);
window.addEventListener("pageshow", clearVendorDataIfOnIndex);
