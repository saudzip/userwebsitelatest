document.addEventListener("DOMContentLoaded", function () {
  const inputs = document.querySelectorAll("#verifyModal .digit-input");
  inputs.forEach((input, idx) => {
    input.addEventListener("input", () => {
      // Only digits allowed
      input.value = input.value.replace(/[^0-9]/g, "");
      if (input.value && idx < inputs.length - 1) {
        inputs[idx + 1].focus();
      }
    });

    input.addEventListener("keydown", (e) => {
      if (e.key === "Backspace" && !input.value && idx > 0) {
        inputs[idx - 1].focus();
      }
    });
  });

  document.getElementById("verifyBtn").addEventListener("click", () => {
    const inputs = document.querySelectorAll("#verifyModal .digit-input");
    const code = Array.from(inputs)
      .map((i) => i.value)
      .join("");
    if (code.length < inputs.length) {
      alert("Please enter all 5 digits");
      return;
    }

    // hide Verify
    const verifyEl = document.getElementById("verifyModal");
    bootstrap.Modal.getInstance(verifyEl).hide();

    // show Welcome
    const welcomeEl = document.getElementById("welcomeModal");
    new bootstrap.Modal(welcomeEl).show();
  });

  document.getElementById("resendCode").addEventListener("click", (e) => {
    e.preventDefault();
    // TODO: front‑end resend logic placeholder
    alert("Code resent!");
  });
});

document.getElementById("signupForm").addEventListener("submit", function (e) {
  e.preventDefault();
  bootstrap.Modal.getInstance(document.getElementById("signupModal")).hide();
  new bootstrap.Modal(document.getElementById("verifyModal")).show();
});

document.addEventListener("DOMContentLoaded", () => {
  // 1) From Forgot → Email Sent
  document.getElementById("doResetBtn").addEventListener("click", () => {
    bootstrap.Modal.getInstance(document.getElementById("forgotModal")).hide();
    new bootstrap.Modal(document.getElementById("emailSentModal")).show();
  });

  // 2) From Email Sent → to resetPasswordModal
  document.getElementById("backToLoginBtn").addEventListener("click", () => {
    bootstrap.Modal.getInstance(
      document.getElementById("emailSentModal")
    ).hide();

    new bootstrap.Modal(document.getElementById("resetPasswordModal")).show();
  });

  // 2) resetPasswordModal → successModal
  document.getElementById("resetPasswordBtn").addEventListener("click", () => {
    bootstrap.Modal.getInstance(
      document.getElementById("resetPasswordModal")
    ).hide();

    new bootstrap.Modal(document.getElementById("successModal")).show();
  });

  // 2) successModal → backToLoginBtn_End
  const successModal = document.getElementById("successModal");
  if (successModal) {
    successModal.addEventListener("click", () => {
      bootstrap.Modal.getInstance(successModal).hide();
      setTimeout(() => {
        const loginModal = document.getElementById("loginModal");
        if (loginModal) {
          new bootstrap.Modal(loginModal).show();
        }
      }, 300);
    });
  }
});
