let vendorImageData = [];

async function getCategories() {
  try {
    const [categoryResponse, vendorResponse] = await Promise.all([
      fetch(`http://100.27.227.121:8000/api/categories`),
      fetch(`http://100.27.227.121:8000/api/vendors`),
    ]);

    const [categoryData, vendorData] = await Promise.all([
      categoryResponse.json(),
      vendorResponse.json(),
    ]);

    const categories = categoryData.result.data;
    vendorImageData = vendorData?.vendors?.data || [];

    console.log("Categories:", categories);
    console.log("Vendor image data:", vendorImageData);

    return categories;
  } catch (error) {
    console.error("Fetch error:", error.message);
    return null;
  }
}

document.addEventListener("DOMContentLoaded", async function () {
  const categories = await getCategories();

  let service;
  const selectedService = localStorage.getItem("moreServices");
  if (selectedService) {
    service = JSON.parse(selectedService);
    populateInfoPanel(service);
    
  } else {
    console.log("No selected service found in local storage.");
    return;
  }

  let matchedVendor = null;
  if (Array.isArray(vendorImageData)) {
    matchedVendor = vendorImageData.find((v) => v.id == service.vendor?.id);
  }

  console.log("matchedVendor", matchedVendor);




  const wellthsection = document.getElementById("wellth-section");
  wellthsection.innerHTML = "";
  const wellthWraper = document.createElement("div");

  // Defensive check for images
  const SelectedVendorData = JSON.parse(
    localStorage.getItem("vendorData") || "{}"
  );

  const city = SelectedVendorData?.cities?.[0]?.name || matchedVendor?.cities[0]?.name;
  const country = SelectedVendorData?.countries?.[0]?.name ||  matchedVendor?.countries[0]?.name;

  const businessHours = SelectedVendorData?.business_hours?.[0]
  ? `${SelectedVendorData.business_hours[0].open} - ${SelectedVendorData.business_hours[0].close}`
  : matchedVendor?.business_hours?.[0]
  ? `${matchedVendor.business_hours[0].open} - ${matchedVendor.business_hours[0].close}`
  : "No Hours";


  const businessDays =
  Array.isArray(SelectedVendorData.business_days) &&
  SelectedVendorData.business_days.length > 0
    ? `${SelectedVendorData.business_days[0]} - ${SelectedVendorData.business_days.at(-1)}`
    : Array.isArray(matchedVendor.business_days) &&
      matchedVendor.business_days.length > 0
    ? `${matchedVendor.business_days[0]} - ${matchedVendor.business_days.at(-1)}`
    : "No Days";


  // Image Fallbacks
  const getImageUrl = (index) =>
  SelectedVendorData?.images?.[index]?.image_path
    ? SelectedVendorData.images[index].image_path
    : matchedVendor?.images?.[index]?.image_path
    ? matchedVendor.images[index].image_path
    : "assets/images/placeholder.jpg"; // fallback image path


  wellthWraper.innerHTML = `
  <div class="">
    <h2>${SelectedVendorData.name ||matchedVendor.name}</h2>
    <p class="wellth-subtitle mt-4">${
      SelectedVendorData.description || matchedVendor.description
    }</p>

    <!-- Header Row -->
    <div class="wellth-header-row">
      <div class="left">
        <div class="d-flex align-items-center gap-2">
          <img src="assets/icons/location.svg" alt="Location" width="20" />
          <small class="text-secondary">${city}, ${country}</small>
        </div>
        <div class="d-flex align-items-center gap-2">
          <img src="assets/icons/clock.svg" alt="Clock" width="20" />
          <small class="text-secondary">${businessHours}, ${businessDays}</small>
        </div>
      </div>

      <div class="right">
        <div class="avatar-group">
          <img src="assets/images/multiple-user.png" class="me-3" width="24" height="24" alt="Group" />
          <img src="assets/images/avatar1.jpg" class="rounded-circle" width="32" alt="User1" />
          <img src="assets/images/avatar.png" class="rounded-circle" width="32" alt="User2" />
          <img src="assets/images/avatar4.jpg" class="rounded-circle" width="32" alt="User3" />
        </div>
        <div class="d-flex align-items-center gap-1">
          <img src="assets/icons/Star 3.svg" alt="Star" width="20" class="me-1" />
          <strong class="me-1">5.0</strong>
          <small class="text-secondary">(312)</small>
        </div>
      </div>
    </div>

    <!-- Image Gallery -->
    <div class="wellth-gallery">
      <div class="wellth-main-img" style="background-image: url('${getImageUrl(
        0
      )}')"></div>
      <div class="wellth-thumbs">
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(
          1
        )}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(
          2
        )}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(
          3
        )}')"></div>
        <div class="wellth-thumb" style="background-image:url('${getImageUrl(
          4
        )}')"></div>
      </div>
    </div>
  </div>
`;

  wellthsection.appendChild(wellthWraper);
  //////////////////////////////////////////////// show Categorries ////////////////////////////////////////////////////////
  const categoriesRapper = document.getElementById("categories-rapper");
  categoriesRapper.innerHTML = "";

  categories.forEach((element, index) => {
    const catIcon = element.icon || "assets/icons/Frame 2.svg";

    const categoryWrapper = document.createElement("div");
    categoryWrapper.innerHTML = `
    <button class="cat-btn ${index === 0 ? "selected" : ""}">
      <img src="${catIcon}" alt="${element.name}" />
      <span>${element.name}</span>
    </button>
  `;
    categoriesRapper.appendChild(categoryWrapper);
  });

  const allCatButtons = categoriesRapper.querySelectorAll(".cat-btn");
  allCatButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      allCatButtons.forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
    });
  });

  /////////////////////////////////////////////////////////////////////////////////////////////////
  const navLinks = document.querySelectorAll(".nav-link");
  const tabContents = document.querySelectorAll(".tab-content");

  navLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault();

      // Remove active class from all nav links
      navLinks.forEach((l) => l.classList.remove("active"));
      this.classList.add("active");

      // Hide all tab contents
      const selectedTab = this.getAttribute("data-tab");
      tabContents.forEach((content) => {
        content.style.display = content.id === selectedTab ? "flex" : "none";
      });
    });
  });

  // Optional: Ensure correct tab is visible on page load (first tab)
  tabContents.forEach((content) => {
    content.style.display = content.id === "recommended" ? "flex" : "none";
  });

  /////////////////////////////////////////////////////////////// Fetching Apis for tabs //////////////////////////////////////////
  let ApiServicesData = [];
  let ApiPacksData = [];
  let ApiMemberShipData = [];
  // Store all services in one place
  let allServices = [];

  async function fetchAllServices() {
    try {
      const [responseServiceApi, responsePackApi, responseMembershipApi] =
        await Promise.all([
          fetch("http://100.27.227.121:8000/api/services"),
          fetch("http://100.27.227.121:8000/api/packs"),
          fetch("http://100.27.227.121:8000/api/memberships"),
        ]);

      // Check for response errors
      if (
        !responseServiceApi.ok ||
        !responsePackApi.ok ||
        !responseMembershipApi.ok
      ) {
        throw new Error("One or more API requests failed");
      }

      const servicesData = await responseServiceApi.json();
      const packsData = await responsePackApi.json();
      const membershipData = await responseMembershipApi.json();

      // Assign data to global variables
      ApiServicesData = servicesData.data?.data || [];
      ApiPacksData = packsData.data?.data || [];
      ApiMemberShipData = membershipData.data?.data || [];
      // Add after you fetch and render
      allServices = [...ApiServicesData, ...ApiPacksData, ...ApiMemberShipData];

      console.log("Services:", ApiServicesData);
      console.log("Packs:", ApiPacksData);
      console.log("Memberships:", ApiMemberShipData);
      renderCardsByType(ApiServicesData, "single");
      renderCardsByType(ApiPacksData, "packs");
      renderCardsByType(ApiMemberShipData, "membership");
      const recommendedServices = ApiServicesData; // show all services
      renderCardsByType(recommendedServices, "recommended");

      // Optionally, you can now call a function to render the data
      // renderTabsData();
    } catch (error) {
      console.error("Failed to fetch service data:", error);
    }
  }

  fetchAllServices();

  function generateSessionCard(service) {
    return `
    <div class="session-card" data-id="${service.id}">
      <h5>${service.service_name || "Untitled Service"}</h5>
      <p>
        ${service.service_description?.slice(0, 60) || "No description"}...
        <a href="#" class="read-more text-muted" data-id="${
          service.id
        }">read more</a>
      </p>
      <div class="session-meta">
        <div class="d-flex align-items-center">
          <span class="text-dark">${
            service.vendor?.currency || "$"
          } ${service.prices || "0.00"}</span>
        </div>
        <div class="d-flex align-items-center">
          <img src="assets/icons/clock.svg" alt="Duration">
          <small>${(service.durations || []).join(" Min, ")} Mins</small>
        </div>
      </div>
      <button class="btn-add">
        <img src="assets/icons/Add_Icon_Wellth.png" alt="icon" class="img-fluid">
      </button>
    </div>
  `;
  }

  document
    .querySelector(".session-list")
    .addEventListener("click", function (e) {
      if (e.target.classList.contains("read-more")) {
        e.preventDefault();
        this.style.display = "none";
        document.getElementById("detail-card").style.display = "block";
      }
    });

  // Event delegation for read-more
  document
    .querySelector(".session-list")
    .addEventListener("click", function (e) {
      if (e.target.classList.contains("read-more")) {
        e.preventDefault();
        const serviceId = e.target.dataset.id;
        const selectedService = allServices.find((s) => s.id == serviceId);
        if (selectedService) {
          populateDetailCard(selectedService);
          document.querySelector(".session-list").style.display = "none";
          document.getElementById("detail-card").style.display = "block";
        }
      }

      if (e.target.classList.contains("read-less")) {
        document.getElementById("detail-card").style.display = "none";
        document.querySelector(".session-list").style.display = "block";
      }
    });

  function populateDetailCard(service) {
    const detail = document.getElementById("detail-card");
    const imageEl = detail.querySelector(".main-img");

    if (imageEl && service.images && service.images.length > 0) {
      imageEl.src = `${service.images[0].image_path}`;
    } else {
      imageEl.src = "assets/images/service3.jpg";
    }

    detail.querySelector("h5").textContent = service.service_name || "Service";
    detail.querySelector(".rating span").textContent = "5.0 (312)";
    detail.querySelector(".meta div:first-child").textContent = `${
      service.vendor?.currency || "$"
    } ${service.prices || "0.00"}`;
    detail.querySelector(".meta small").textContent = `${service.durations.join(
      "Min, "
    )}Min`;
    detail.querySelector(".description p").textContent =
      service.service_description || "No description";
    detail.querySelector(".benefits p").textContent =
      service.service_benefits || "No benefits listed";

    // 🔽 Set the ID for later use
    const addBtn = detail.querySelector("#detail-add-btn");
    if (addBtn) {
      addBtn.dataset.id = service.id;
    }
  }

  // grab references
  const cardwellth_ID = document.getElementById("cardwellth_ID");
  const cardwellth_Expand_ID = document.getElementById("cardwellth_Expand_ID");
  const Info_cardwellth_ID = document.getElementById("Info_cardwellth_ID");
  const Info_actions_button1 = document.getElementById("Info_actions_button1");
  const Info_actions_button2 = document.getElementById("Info_actions_button2");

  // FIXED: Unified event handler for both btn-add and detail-add-btn
  document.body.addEventListener("click", (e) => {
    const addBtn = e.target.closest(".btn-add");
    const detailAddBtn = e.target.closest("#detail-add-btn");

    if (addBtn || detailAddBtn) {
      let selectedService;

      if (addBtn) {
        // Handle regular .btn-add clicks
        const sessionCard = addBtn.closest(".session-card");
        const serviceId = sessionCard?.dataset.id;
        selectedService = allServices.find((s) => s.id == serviceId);
        console.log("Regular btn-add clicked, service ID:", serviceId);
      } else if (detailAddBtn) {
        // Handle #detail-add-btn clicks
        const serviceId = detailAddBtn.dataset.id;
        selectedService = allServices.find((s) => s.id == serviceId);
        console.log("Detail btn-add clicked, service ID:", serviceId);
      }

      if (!selectedService) {
        console.error("No service found for the clicked button");
        return;
      }

      console.log("Selected service:", selectedService);

      // Show expanded booking panel and hide the regular panels
      cardwellth_ID.classList.add("hide");
      Info_cardwellth_ID.classList.add("hide");
      cardwellth_Expand_ID.classList.remove("hide");

      // Hide session heading
      const headingEl = document.getElementById("session-heading-wrapper");
      if (headingEl) headingEl.classList.add("hide");

      // Populate booking panel and info panel with selected service
      populateExpandedPanel(selectedService);
      populateInfoPanel(selectedService);

      // Enable/disable buttons as needed
      Info_actions_button1.disabled = true;
      Info_actions_button2.disabled = false;

      // If clicked from detail card, hide detail card and show service list
      if (detailAddBtn) {
        document.getElementById("detail-card").style.display = "none";
        document.querySelector(".session-list").style.display = "block";
      }
    }
  });

  //////////////////////////////////////////// booking ///////////////////////////////////////

function formatTimeSlot(open, close) {
  return `
    <div class="time-slot" data-slot="${open}–${close}">
      <div class="slot-info">
        <img src="assets/icons/clock.svg" alt="" />
        <span>${open} – ${close}</span>
      </div>
    </div>`;
}

function generateTimeSlotsHTML(service) {
  if (!service) {
    console.error("Service is undefined:", service);
    return "";
  }
  const businessHours = service.vendor.business_hours;

  let slotsHTML = "";

  businessHours.forEach((hour) => {
    if (businessHours.length > 0) {
      slotsHTML += formatTimeSlot(hour.open, hour.close);
    } else {
      slotsHTML += `<p>No Business Hours Available</p>`;
    }
  });

  return slotsHTML;
}


function updateBookNowState(wrapper) {
  const dateSelected = wrapper.querySelector(".date-pill.selected")?.dataset.day;
  const timeSelected = wrapper.querySelector(".time-slot.selected")?.dataset.slot;
  const bookNowBtn = wrapper.querySelector("#bookNow");

  if (dateSelected && timeSelected) {
    bookNowBtn.disabled = false;
  } else {
    bookNowBtn.disabled = true;
  }
}


function populateExpandedPanel(service) {
  const panel = document.getElementById("cardwellth_Expand_ID");
  panel.innerHTML = "";
  const wrapperDiv = document.createElement("div");

  const price = service.prices ?? "N/A";
  const currency = service.vendor.currency ?? "N/A";
  const duration = service.durations.join("Min, ") ?? "N/A";
  const title = service.service_name ?? "Service";

  wrapperDiv.innerHTML = `
    <div class="expanded-panel toggle-div" id="expanded-panel_home_ID">
        <h5>${title}</h5>
        <div class="meta-row">
          <div class="slot-info">
            <strong>${price}</strong>
            <span>${currency}</span>
          </div>
          <div class="slot-info">
            <img src="assets/icons/clock.svg" alt="Clock" />
            <span>${duration}Mins</span>
          </div>
          <button class="btn-add" fdprocessedid="dguv8q">
            <img src="assets/icons/Arrow_bottom.svg" />
          </button>
        </div>

        <!-- Date selector -->
<div class="section-label">Select Date</div>
<div class="date-selector" id="dynamic-date-pills">
  <!-- Date pills will be injected here -->
</div>


          <!-- Hidden native picker (must be outside the pill) -->
          <input
            type="text"
            id="custom-date-input"
            style="display: none"
            class="flatpickr-input"
            readonly="readonly"
          />
        </div>

          <!-- Time slots -->
    <div class="section-label">Select Time</div>
    <div class="time-list" id="time-slots-list" >
      ${generateTimeSlotsHTML(service)}
    </div>
        <div class="Info_actions">
          <button id="bookNow"   class="btn  continue-btn" disabled>Book Now</button>
          <button id="bookLater" class="btn book-later-btn">Book Later</button>
        </div>
      </div>
  `;

  //generate dates
  const dateSelector = wrapperDiv.querySelector("#dynamic-date-pills");
  const today = new Date();

  for (let i = 0; i < 3; i++) {
    const currentDate = new Date(today);
    currentDate.setDate(today.getDate() + i);

    const weekday = currentDate.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
    const month = currentDate.toLocaleDateString("en-US", { month: "short" });
    const day = currentDate.getDate().toString().padStart(2, "0");

    const pillDiv = document.createElement("div");
    pillDiv.className = "date-pill";
    pillDiv.dataset.day = `${weekday} ${month} ${day}`;
    pillDiv.innerHTML = `
    <div class="day">${weekday}</div>
    <small>${month} ${day}</small>
  `;

    dateSelector.appendChild(pillDiv);
  }

  const customPill = document.createElement("div");
  customPill.className = "date-pill more";
  customPill.id = "custom-date-pill";
  customPill.innerHTML = `<img src="assets/icons/calendar.svg" alt="More" />`;

  dateSelector.appendChild(customPill);

  // Also append the hidden input (must come after the custom pill)
  const customInput = document.createElement("input");
  customInput.type = "text";
  customInput.id = "custom-date-input";
  customInput.style.display = "none";
  customInput.className = "flatpickr-input";
  customInput.readOnly = true;

  dateSelector.appendChild(customInput);


  // Date pill selection
  wrapperDiv.querySelectorAll(".date-pill").forEach((pill) => {
    pill.addEventListener("click", () => {
      wrapperDiv
        .querySelectorAll(".date-pill")
        .forEach((d) => d.classList.remove("selected"));
      if (!pill.classList.contains("more")) {
        pill.classList.add("selected");
        updateBookNowState(wrapperDiv);
      }

    });
  });

  // Time slot selection
  wrapperDiv.querySelectorAll(".time-slot").forEach((slot) => {
    slot.addEventListener("click", () => {
      wrapperDiv
        .querySelectorAll(".time-slot")
        .forEach((s) => s.classList.remove("selected"));
      slot.classList.add("selected");
      updateBookNowState(wrapperDiv);
    });
  });

  // Flatpickr
  const pill = wrapperDiv.querySelector("#custom-date-pill");
  const picker = wrapperDiv.querySelector("#custom-date-input");

  console.log("picker", picker);
  console.log("pill", pill);

  if (picker && pill) {
    console.log("come inside date picker");
    flatpickr(picker, {
      defaultDate: null,
      allowInput: false,
      clickOpens: false,
      minDate: "today", // ✅ This disables all dates before today
      onChange: function (selectedDates, dateStr) {
        if (!dateStr) return;
        const dt = selectedDates[0];
        const weekday = dt.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
        const month = dt.toLocaleDateString("en-US", { month: "short" });
        const dayNum = dt.getDate().toString().padStart(2, "0");

        pill.dataset.day = `${weekday} ${month} ${dayNum}`;
        pill.innerHTML = `
      <div class="day">${weekday}</div>
      <small>${month} ${dayNum}</small>
    `;
        pill.classList.add("selected");
        updateBookNowState(wrapperDiv); // ✅ Make sure to update the state
      },
      onReady: function (_, __, fp) {
        const calendar = fp.calendarContainer;
        calendar.classList.add("flatpickr-calendar");
      }
    });


    pill.addEventListener("click", () => {
      const isOpen = picker._flatpickr.isOpen;
      if (isOpen) picker._flatpickr.close();
      else picker._flatpickr.open();
    });
  }

  wrapperDiv.querySelector("#bookNow").addEventListener("click", (e) => {
    e.preventDefault();

    // Get selected date
    const selectedDatePill = wrapperDiv.querySelector(".date-pill.selected");
    const selectedDate = selectedDatePill ? selectedDatePill.dataset.day : null;

    // Get selected time slot
    const selectedTimeSlot = wrapperDiv.querySelector(".time-slot.selected");
    const timeSlot = selectedTimeSlot ? selectedTimeSlot.dataset.slot : null;

    // Combine everything into a single object
    const payload = {
      bookType:"bookNow",
      service,
      selectedDate,
      timeSlot,
    };

    console.log("Payload:", payload);
    // Save to localStorage
    localStorage.setItem("selectedBookingData", JSON.stringify(payload));

    // Navigate to service.html
    window.location.href = "service.html";
  });

  wrapperDiv.querySelector("#bookLater").addEventListener("click", (e) => {
    e.preventDefault();

    // Get selected date
    // const selectedDatePill = wrapperDiv.querySelector(".date-pill.selected");
    // const selectedDate = selectedDatePill ? selectedDatePill.dataset.day : null;

    // Get selected time slot
    // const selectedTimeSlot = wrapperDiv.querySelector(".time-slot.selected");
    // const timeSlot = selectedTimeSlot ? selectedTimeSlot.dataset.slot : null;

    // Combine everything into a single object
    const payload = {
      bookType:"bookLater",
      service,
      selectedDate:"",
      timeSlot:"",
    };

    console.log("PayloadbookLater:", payload);
    // Save to localStorage
    localStorage.setItem("selectedBookingLaterData", JSON.stringify(payload));

    // Navigate to service.html
    window.location.href = "Review.html";
  });

  panel.appendChild(wrapperDiv);
}



  ///////////////////////////////////////////////////// Info Panel ////////////////////////////////

  function populateInfoPanel(service) {
    const infoPanel = document.getElementById("Info_cardwellth_ID");

    if (!service || !infoPanel) return;

    console.log("Populating info panel with service:", service);

    // Set name
    const titleEl = infoPanel.querySelector("h3");
    if (titleEl) {
      titleEl.textContent = service.vendor?.name || "Business Name";
    }

    // Set location
    const locationEl = infoPanel.querySelectorAll("small")[0];
    if (locationEl) {
      locationEl.textContent = `${service.city?.[0]?.name || "N/A"}, ${
        service.countries?.[0]?.name || "N/A"
      }`;
    }

    // Set operating hours
    const hoursEl = infoPanel.querySelectorAll("small")[1];
    if (hoursEl) {
      hoursEl.textContent = service.vendor?.timing || "9AM–10PM, Mon–Sun";
    }

    // Set rating
    const ratingSpan = infoPanel.querySelector("span.fw-semibold");
    const reviewsEl = infoPanel.querySelectorAll("small")[2];
    if (ratingSpan) {
      ratingSpan.textContent = service.vendor?.rating || "5.0";
    }
    if (reviewsEl) {
      reviewsEl.textContent = `(${service.vendor?.reviews_count || 0})`;
    }
  }

  document
    .getElementById("detail-card")
    .addEventListener("click", function (e) {
      if (e.target.classList.contains("read-less")) {
        this.style.display = "none";
        document.querySelector(".session-list").style.display = "block";
      }
    });

  ////////////////////////////////////////////// populate more content  about//////////////////

  function populateMoreContent() {
    const moreContent = document.querySelector(".more-content");
    if (!moreContent) {
      console.warn("Missing #moreContent container in the DOM.");
      return;
    }

    // Populate About section
    const aboutSection = moreContent.querySelector(".section p");
    if (aboutSection) {
      const aboutText =
        SelectedVendorData.description||matchedVendor.description || "No description available.";
      aboutSection.innerHTML = aboutText;
    }

    // Populate Map
    const address = SelectedVendorData.address||matchedVendor.address || "Unknown location";
    const mapSection = moreContent.querySelector("#map");
    const mapWrapper = mapSection?.parentElement;
    const locationLink = mapWrapper?.querySelector("p a");

    if (mapSection && mapWrapper && locationLink) {
      if (service.vendor?.location?.lat && service.vendor?.location?.lng) {
        const { lat, lng } = service.vendor.location;
        const mapIframe = document.createElement("iframe");
        mapIframe.src = `https://www.google.com/maps?q=${lat},${lng}&z=15&output=embed`;
        mapIframe.width = "100%";
        mapIframe.height = "300";
        mapIframe.style.border = "0";
        mapSection.innerHTML = ""; // Clear placeholder
        mapSection.appendChild(mapIframe);
        locationLink.href = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
      } else {
        mapSection.innerHTML = `<span>Map not available for this location.</span>`;
        locationLink.href = "#";
      }
      locationLink.textContent = "Get directions";
      mapWrapper.querySelector("p").textContent = `${address} `;
      mapWrapper.querySelector("p").appendChild(locationLink);
    }

    // Populate Opening Times
    const openingTimesBlock = moreContent.querySelector(".opening-times");
    if (openingTimesBlock) {
      openingTimesBlock.innerHTML = "";
      const hours = SelectedVendorData.business_hours || matchedVendor.business_hours|| [];
      const days =  SelectedVendorData.business_days || matchedVendor.business_days || [];

      if (hours.length || days.length) {
        hours.forEach((hour) => {
          const day = days[0] || "Open";
          const line = document.createElement("div");
          line.classList.add("fw-semibold");
          line.innerHTML = `🟢 ${day} <span>${hour.open} - ${hour.close}</span>`;
          openingTimesBlock.appendChild(line);
        });
      } else {
        openingTimesBlock.innerHTML = "<p>No opening times available.</p>";
      }
    }

    // Populate Additional Info
    const infoBlock = moreContent.querySelector(".additional-info");
    if (infoBlock) {
      infoBlock.innerHTML = "";
      const infos = service.vendor?.additional_info || [];
      if (infos.length) {
        infos.forEach((info) => {
          const p = document.createElement("p");
          p.innerHTML = `<i class="bi bi-check2 me-2 fw-semibold"></i>${info}`;
          infoBlock.appendChild(p);
        });
      } else {
        infoBlock.innerHTML = "<p>No additional information available.</p>";
      }
    }
  }

  function renderCardsByType(data, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = ""; // Clear existing content

    if (!Array.isArray(data) || data.length === 0) {
      container.innerHTML = `
      <div class="text-center text-muted py-3">
        <p>No services available in this service type.</p>
      </div>
    `;
      return;
    }

    data.forEach((service) => {
      const cardHTML = generateSessionCard(service);
      const tempDiv = document.createElement("div");
      tempDiv.innerHTML = cardHTML;
      container.appendChild(tempDiv.firstElementChild);
    });
  }

  $(document).ready(function () {
    // Category picker
    $(".time-picker").select2({
      placeholder: "Select a time",
      allowClear: true,
    });
  });


  populateMoreContent();
  //////////////////////////////////////////////////////// End of Code ////////////////////////////////////////////////////////
});


