async function  createCustomer(customer) {
  const response = await fetch("http://100.27.227.121:8000/api/customers", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(customer),
  });}