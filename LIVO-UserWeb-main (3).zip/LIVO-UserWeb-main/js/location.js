const base_url = "http://100.27.227.121:8000/api";

// Store vendors data globally for filtering
let allVendors = [];
let currentFilter = 'mostBooked';

async function getServices() {
  const fetchedServices = [];
  const fetchedVendors = [];

  try {
    // Show loading spinner
    showLoading();

    // Fetch all pages of services
    let servicePage = 1;
    let serviceLastPage = 1;

    do {
      const serviceRes = await fetch(`${base_url}/services?page=${servicePage}`);

      if (!serviceRes.ok)
        throw new Error(`Service fetch failed: ${serviceRes.status}`);
      const serviceJson = await serviceRes.json();
      console.log("serviceRes", serviceJson);

      fetchedServices.push(...serviceJson.data.data);
      serviceLastPage = serviceJson.data.last_page;
      servicePage++;
    } while (servicePage <= serviceLastPage);

    // Fetch all pages of vendors
    let vendorPage = 1;
    let vendorLastPage = 1;

    do {
      const vendorRes = await fetch(`${base_url}/vendors?page=${vendorPage}`);
      if (!vendorRes.ok)
        throw new Error(`Vendor fetch failed: ${vendorRes.status}`);
      const vendorJson = await vendorRes.json();
      console.log("vendorRes", vendorJson);

      fetchedVendors.push(...vendorJson.vendors.data);
      vendorLastPage = vendorJson.vendors.last_page;
      vendorPage++;
    } while (vendorPage <= vendorLastPage);

    console.log("All Services:", fetchedServices);
    console.log("All Vendors:", fetchedVendors);

    // Store vendors globally for filtering
    allVendors = fetchedVendors;

    // Create cards
    createServiceCards(fetchedServices);
    createVendorCards(fetchedVendors);

    // Hide loading spinner
    hideLoading();

    return { services: fetchedServices, vendors: fetchedVendors };
  } catch (error) {
    console.error("Fetch error:", error.message);
    hideLoading();
    showError("Failed to load data. Please try again later.");
    return null;
  }
}

function createVendorCards(vendors) {
  const container = document.getElementById("ApiVendors");
  
  if (!container) {
    console.error("ApiVendors container not found");
    return;
  }

  // Clear existing content
  container.innerHTML = "";

  if (!vendors || vendors.length === 0) {
    container.innerHTML = `
      <div class="text-center py-5">
        <p class="text-muted">No facilities found</p>
      </div>
    `;
    return;
  }

  // Create cards grid
  const cardsGrid = document.createElement("div");
  cardsGrid.className = "row g-4";

  vendors.forEach((vendor, index) => {
    const colDiv = document.createElement("div");
    colDiv.className = "col-lg-4 col-md-6 col-sm-12";

    // Safe fallback values
    const name = vendor.name || "Unknown Facility";
    const location = getVendorLocation(vendor);
    const rating = vendor.rating || "0.0";
    const reviewCount = vendor.reviews_count || "0";
    const description = vendor.description || "No description available.";
    const logoUrl = vendor.logo ? `http://100.27.227.121/logo/${vendor.logo}` : 'assets/images/default-facility.png';

    colDiv.innerHTML = `
      <div class="card h-100 custom-card_facility shadow-sm" data-index="${index}">
        <div class="position-relative">
          <a href="Wellth.html" class="vendor-link">
            <img src="${logoUrl}" 
                 class="card-img_facility" 
                 alt="${name}"
                 onerror="this.src='assets/images/default-facility.png'" />
          </a>
          <button class="btn btn-light btn-sm favorite-btn position-absolute top-0 end-0 m-2">
            <a href="favourite.html" style="text-decoration: none; color:black">
              <i class="bi bi-heart"></i>
            </a>
          </button>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-1">
            <a href="Wellth.html" class="card-title mb-1 vendor-link text-decoration-none fw-bold">${name}</a>
            <div class="rating-section">
              <i class="bi bi-star-fill text-warning"></i>
              <span class="fw-bold">${rating}</span>
              <small class="text-muted">(${reviewCount})</small>
            </div>
          </div>
          <p class="text-muted fw-medium mb-2">
            <i class="bi bi-geo-alt-fill"></i> ${location}
          </p>
          <p class="mb-0 text-secondary" style="color: #6e6a6a">${truncateText(description, 100)}</p>
        </div>
      </div>
    `;

    // Add event listeners to vendor links
    const links = colDiv.querySelectorAll(".vendor-link");
    links.forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        // Store vendor data in session storage or pass via URL parameters
        storeVendorData(vendor);
        window.location.href = "Wellth.html";
      });
    });

    cardsGrid.appendChild(colDiv);
  });

  container.appendChild(cardsGrid);
}

// Placeholder for createServiceCards function
function createServiceCards(services) {
  console.log("Creating service cards:", services);
  // Implement service cards creation if needed
}

// Helper functions
function getVendorLocation(vendor) {
  const city = vendor.cities?.[0]?.name || "Unknown City";
  const country = vendor.countries?.[0]?.name || "Unknown Country";
  return `${city}, ${country}`;
}

function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + "...";
}

function storeVendorData(vendor) {
  // Instead of localStorage, we'll use sessionStorage or URL parameters
  try {
    sessionStorage.setItem("vendorData", JSON.stringify(vendor));
  } catch (error) {
    console.warn("Session storage not available, using URL parameters");
    // Fallback: encode essential data in URL
    const params = new URLSearchParams({
      vendorId: vendor.id,
      vendorName: vendor.name,
      vendorRating: vendor.rating || 0
    });
    window.location.href = `Wellth.html?${params.toString()}`;
  }
}

function showLoading() {
  const container = document.getElementById("ApiVendors");
  if (container) {
    container.innerHTML = `
      <div class="d-flex align-items-center justify-content-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
        <span class="ms-3">Loading facilities...</span>
      </div>
    `;
  }
}

function hideLoading() {
  // Loading will be replaced by actual content
}

function showError(message) {
  const container = document.getElementById("ApiVendors");
  if (container) {
    container.innerHTML = `
      <div class="alert alert-danger" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        ${message}
      </div>
    `;
  }
}

// Filter functionality
function applyFilter(filterType) {
  currentFilter = filterType;
  let sortedVendors = [...allVendors];

  switch (filterType) {
    case 'mostBooked':
      sortedVendors.sort((a, b) => (b.bookings_count || 0) - (a.bookings_count || 0));
      break;
    case 'mostReviewed':
      sortedVendors.sort((a, b) => (b.reviews_count || 0) - (a.reviews_count || 0));
      break;
    case 'nearest':
      // This would require user location - for now just sort by name
      sortedVendors.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case 'priceLowHigh':
      sortedVendors.sort((a, b) => (a.min_price || 0) - (b.min_price || 0));
      break;
    case 'priceHighLow':
      sortedVendors.sort((a, b) => (b.max_price || 0) - (a.max_price || 0));
      break;
    default:
      break;
  }

  createVendorCards(sortedVendors);
}

// Initialize when DOM is loaded
document.addEventListener("DOMContentLoaded", async () => {
  console.log("DOM loaded, fetching services and vendors...");
  await getServices();

  // Set up filter functionality
  const applyBtn = document.getElementById('applyBtn');
  if (applyBtn) {
    applyBtn.addEventListener('click', () => {
      const selected = document.querySelector('input[name="filter"]:checked');
      if (selected) {
        applyFilter(selected.value);
      }
      // Close modal
      const filterModal = document.getElementById('filterModal');
      if (filterModal) {
        filterModal.style.display = 'none';
      }
    });
  }
});

// Export functions for external use
window.getServices = getServices;
window.createVendorCards = createVendorCards;
window.applyFilter = applyFilter;