
//   function showLogin() {
//     document.getElementById("loginModal").style.display = "block";
//     document.getElementById("signupModal").style.display = "none";
//   }

//   function showSignup() {
//     document.getElementById("signupModal").style.display = "block";
//     document.getElementById("loginModal").style.display = "none";
//   }

//   function handleSignup() {
//     const user = document.getElementById("signupUser").value;
//     const pass = document.getElementById("signupPass").value;
//     localStorage.setItem("user_" + user, pass);
//     alert("Signup successful! Now log in.");
//     showLogin();
//   }

//   function handleLogin() {
//     const user = document.getElementById("loginUser").value;
//     const pass = document.getElementById("loginPass").value;
//     const stored = localStorage.getItem("user_" + user);

//     if (stored && stored === pass) {
//       localStorage.setItem("loggedInUser", user);
//       alert("Logged in!");
//       location.reload();
//     } else {
//       alert("Invalid credentials");
//     }
//   }

//   function isLoggedIn() {
//     return !!localStorage.getItem("loggedInUser");
//   }

//   function useFeature() {
//     if (!isLoggedIn()) {
//       alert("You must log in or sign up to use this feature.");
//       showLogin();
//       return;
//     }

//     alert("Using protected feature!");
//   }

//   // 🧠 Auto-run on page load
//   document.addEventListener("DOMContentLoaded", () => {
//     if (!isLoggedIn()) {
//       showLogin();
//     } else {
//       alert("Welcome back, " + localStorage.getItem("loggedInUser") + "!");
//     }
//   });


/////////////////////////////////////////////////////// Singn up function //////////////////////////////

// const base_url = "http://100.27.227.121:8000/api";

async function Signup() {
  try {
    const response = await fetch("http://100.27.227.121:8000/api/customers", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        first_name: document.getElementById("signupFirstName").value,
        last_name: document.getElementById("signupLastName").value,
        email: document.getElementById("signupEmail").value,
        password: document.getElementById("signupPass").value,
        password_confirmation: document.getElementById("signupConfirmPass").value,
        phone: document.getElementById("phone").value,
        active: "true",
      }),
    });

    const contentType = response.headers.get("content-type");

    if (contentType && contentType.includes("application/json")) {
      const result = await response.json();

      if (response.ok) {
        // ✅ User successfully signed up
        localStorage.setItem("loggedInUser", "true");

        // Close signup modal
        const signupModalEl = document.getElementById("signupModal");
        const signupModal = bootstrap.Modal.getInstance(signupModalEl);
        if (signupModal) signupModal.hide();

        alert("Signup successful! 🎉");
      } else {
        // ❌ Handle error returned from server JSON
        alert(result.message || "Signup failed.");
      }
    } else {
      // Response is not JSON (likely HTML error page)
      const text = await response.text();
      console.error("Non-JSON response from server:", text);
      alert("Signup failed: Server returned unexpected response.");
    }
  } catch (e) {
    console.error("Signup error:", e);
    alert("Something went wrong. Please try again.");
  }
}


async function Signin() {
  try {
    const response = await fetch("http://100.27.227.121:8000/api/customers", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: document.getElementById("signinEmail").value,
        password: document.getElementById("signinPass").value,
      }),
    });

    const contentType = response.headers.get("content-type");

    if (contentType && contentType.includes("application/json")) {
      const result = await response.json();

      if (response.ok) {
        // ✅ User successfully signed in
        localStorage.setItem("loggedInUser", "true");
        localStorage.setItem("userData", JSON.stringify(result)); // optional: store user data

        // Close signin modal
        const signinModalEl = document.getElementById("signinModal");
        const signinModal = bootstrap.Modal.getInstance(signinModalEl);
        if (signinModal) signinModal.hide();

        alert("Signin successful! 👋");
      } else {
        // ❌ Invalid credentials or error
        alert(result.message || "Signin failed. Please check your email and password.");
      }
    } else {
      const text = await response.text();
      console.error("Non-JSON response from server:", text);
      alert("Signin failed: Server returned unexpected response.");
    }
  } catch (e) {
    console.error("Signin error:", e);
    alert("Something went wrong. Please try again.");
  }
}




document.addEventListener('DOMContentLoaded', function () {
  const modalEl = document.getElementById('welcomeModal');
  let welcomeModal = null;

  document.addEventListener('click', function (event) {
    const isLoggedIn = !!localStorage.getItem('loggedInUser');
    if (isLoggedIn) return;

    const target = event.target;

    // ⛔ Do NOT show if the click is inside ANY open modal (excluding welcomeModal)
    if (target.closest('.modal.show') && !modalEl.classList.contains('show')) {
      return;
    }

    // ⛔ Do NOT trigger if clicking buttons, links, or form fields
    if (
      target.closest('button') ||
      target.closest('a') ||
      target.closest('input') ||
      target.closest('select') ||
      target.closest('textarea')
    ) {
      return;
    }

    // ✅ Show the welcomeModal if it's not already open
    if (!welcomeModal) {
      welcomeModal = new bootstrap.Modal(modalEl, {
        backdrop: 'static',
        keyboard: false
      });
      welcomeModal.show();
    } else {
      // Optional: Close and reset if already open
      welcomeModal.hide();
      welcomeModal = null;
      document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    }
  });
});




