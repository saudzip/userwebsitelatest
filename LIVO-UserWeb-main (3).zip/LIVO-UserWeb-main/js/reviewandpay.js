function getSelectedService() {
  const selectedBookingData = localStorage.getItem("selectedBookingData");
  const selectedBookingLaterData = localStorage.getItem("selectedBookingLaterData");

  if (selectedBookingData) {
    const { bookType, service, selectedDate, timeSlot } = JSON.parse(selectedBookingData);
    console.log("Using selectedBookingData:");
    console.log(bookType, service, selectedDate, timeSlot);
    return { service, selectedDate, timeSlot };
  }

  if (selectedBookingLaterData) {
    const { bookType, service, selectedDate, timeSlot } = JSON.parse(selectedBookingLaterData);
    console.log("Using selectedBookingLaterData:");
    console.log(bookType, service, selectedDate, timeSlot);
    return { service, selectedDate, timeSlot };
  }

  return null;
}


async function Booking(bookingData) {
  try {
    const response = await fetch(
      "http://100.27.227.121:8000/api/booking",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // Add Authorization if needed
        },
        body: JSON.stringify(bookingData),
      }
    );

    if (!response.ok) {
      throw new Error(`Server responded with ${response.status}`);
    }

    const result = await response.json();
    // alert("Booking successfull");
    return result;
  } catch (error) {
    alert("Booking failed:\n" + error.message);
    console.log("Booking failed:\n" + error.message);
    return null;
  }
}


document.addEventListener("DOMContentLoaded", () => {
  const bsModal = new bootstrap.Modal(
    document.getElementById("confirmationModal")
  );
  const selectedService = getSelectedService();

  console.log("selectedService:", selectedService);

  if (!selectedService || !selectedService.service) {
    document.getElementById("SelectedServiceData").innerHTML =
      "<p class='text-danger'>No service selected.</p>";
    return;
  }

  // 1. Render selected service UI
  const serviceDataContainer = document.getElementById("SelectedServiceData");
  serviceDataContainer.innerHTML = "";

  const wrapperDiv = document.createElement("div");
  wrapperDiv.classList.add("d-flex", "align-items-center");

console.log("Selected Service:", selectedService);
console.log("Service URL:", selectedService.service?.url);
console.log("Images:", selectedService.service?.images);




  let imageUrl = "assets/images/Wellth (2).jpg";

if (
  selectedService.service &&
  selectedService.service.images &&
  selectedService.service.images.length > 0 &&
  typeof selectedService.service.images[0].image_path === "string"
) {
  const imagePath = selectedService.service.images[0].image_path.replace(/^\//, "");

  if (typeof selectedService.service.url === "string" && selectedService.service.url.trim() !== "") {
    const cleanedUrl = selectedService.service.url.replace(/\/$/, "");
    imageUrl = `https://${cleanedUrl}/${imagePath}`;
  } else {
    // Use only the image path if URL is missing
    imageUrl = imagePath.startsWith("http")
      ? imagePath
      : `assets/images/${imagePath}`;
  }
}




  console.log("Image URL:", imageUrl);


  const location =
    Array.isArray(selectedService.service.location_types) &&
      selectedService.service.location_types.length > 0
      ? selectedService.service.location_types.join(", ")
      : "Dubai, UAE";

  const business_days = selectedService.service.vendor.business_days || [];
  const business_hours = selectedService.service.vendor.business_hours || [];

  // Flatten the days array
  const days = business_days.flat();  // ['Monday', 'Tuesday', 'Wednesday', ...]

  // Map full day names to abbreviations
  const dayMap = {
    Monday: "Mon",
    Tuesday: "Tue",
    Wednesday: "Wed",
    Thursday: "Thu",
    Friday: "Fri",
    Saturday: "Sat",
    Sunday: "Sun"
  };
  const abbreviatedDays = days.map(day => dayMap[day] || day);

  // Join days with " - "
  const dayString = abbreviatedDays.join(" - ");

  // Convert 24-hour time to 12-hour format with AM/PM
  function convertTime24to12(time24) {
    const [hourStr, minuteStr] = time24.split(":");
    let hour = parseInt(hourStr, 10);
    const minute = minuteStr;
    const ampm = hour >= 12 ? "PM" : "AM";
    hour = hour % 12 || 12;
    return `${hour}:${minute} ${ampm}`;
  }

  const startTime = convertTime24to12(business_hours[0].open);
  const endTime = convertTime24to12(business_hours[0].close);

  const displayString = `${startTime} - ${endTime}, ${dayString}`;

  console.log(displayString);
  // Example output: 8:00 AM - 8:00 PM, Mon - Tue - Wed - Thu - Fri - Sat - Sun


  wrapperDiv.innerHTML = `
            <div class="me-3 mb-3" style="width: 100px; height: 100px; ">
                <img src="${imageUrl}" alt="Service thumbnail" class="img-fluid rounded"
                    style="width:100%; height:100%; object-fit:cover;">
            </div>
            <div class="lh-3">
                <h3 class="mb-1">${selectedService.service.service_name}</h3>
                <p class="mb-1 text-muted">${location}</p>
                <p class="mb-0 text-muted">${displayString}</p>
            </div>
        `;
  serviceDataContainer.appendChild(wrapperDiv);

  // 2. Render booking details
  const bookingDetailsContainer = document.getElementById(
    "booking-details-container"
  );
  bookingDetailsContainer.innerHTML = "";

  const selectedDate = selectedService.selectedDate || "Booking Date and";
  const timeSlot = selectedService.timeSlot || "Time Slot are not selected";
  const serviceName = selectedService.service.service_name || "Service Name";
  const price = selectedService.service.prices || 0;
  const currency = selectedService.service.vendor.currency || "USD";

  const bookingWrapperDiv = document.createElement("div");
  bookingWrapperDiv.innerHTML = `
            <h6 class="fw-bold mb-3">Booking Details</h6>
            <div class="d-flex align-items-start mb-3 gap-3">
                <i class="bi bi-calendar2-event fs-4 me-2 text-secondary"></i>
                <div><p class="mb-1 small">${selectedDate} ${timeSlot}</p></div>
            </div>
            <div class="row mb-2">
                <div class="col-sm"><p class="mb-1">${serviceName}</p></div>
                <div class="col-sm-auto"><p class="mb-1 fw-semibold">${currency} ${price}</p></div>
            </div>
            <div class="d-flex justify-content-between border-top pt-2 mt-2">
                <span class="fw-semibold">Total</span>
                <span class="fw-bold fs-5">${currency} ${price}</span>
            </div>
        `;
  bookingDetailsContainer.appendChild(bookingWrapperDiv);

  // 3. Handle Confirm & Pay button
  document.getElementById("btnConfirmPay").addEventListener("click", async () => {
    const notes = document.getElementById("notes")?.value || "";

    function formatDateTime(date = new Date()) {
      const pad = (n) => n.toString().padStart(2, "0");
      const yyyy = date.getFullYear();
      const mm = pad(date.getMonth() + 1);
      const dd = pad(date.getDate());
      const hh = pad(date.getHours());
      const min = pad(date.getMinutes());
      const ss = pad(date.getSeconds());
      return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
    }

    function formatDateOnly(dateStr) {
      if (!dateStr) return "2025-04-24";
      const date = new Date(dateStr);
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, "0");
      const dd = String(date.getDate()).padStart(2, "0");
      return `${yyyy}-${mm}-${dd}`;
    }

    // Get values from selectedService or fallback
    const bookingDatetimeVar = formatDateTime();
    const purchaseDateVar = selectedService.selectedDate;
    const serviceTypeVar = selectedService.service.service_type;
    const servicesIdVar = selectedService.service.id;
    const vendorIdVar = selectedService.service.vendor.id;
    const notesVar = notes;

    const bookingDatetime = bookingDatetimeVar || formatDateTime();
    const purchaseDate = formatDateOnly(purchaseDateVar) || "";
    const serviceType = serviceTypeVar || "single";
    const servicesId = servicesIdVar || "62907428-0f14-40d2-868b-9c5f26f151cf";
    const vendorId = vendorIdVar || "09b796a6-e397-43a4-b921-0c8ed932c859";
    const notesText = notesVar || "Customer prefers afternoon slot.";

    const bookingData = {
      customer_id: "ab545916-a0c6-4c64-8dcc-747d6e25d1eb",
      booking_datetime: bookingDatetime,
      purchase_date: purchaseDate,
      service_type: serviceType,
      services_id: servicesId,
      remaining_sessions: 5,
      vendor_id: vendorId,
      notes: notesText,
      status: "pending",
      active: "yes",
    };

    function populateBookingModal(result) {
      console.log("Booking Result:", result.result);

      const bookingId = result.result.id || "#Unknown";

      // Parse booking_datetime: "2025-05-29 06:29:25"
      let date = selectedService.selectedDate || "N/A";
      let time = selectedDate.timeSlot || "N/A";

      document.getElementById("modalBookingID").textContent = `#${bookingId.slice(0, 8).toUpperCase()}`;
      document.getElementById("modalBookingDate").textContent = date;
      document.getElementById("modalBookingTime").textContent = time;
    }

    const result = await Booking(bookingData);
    console.log("Booking Data:", bookingData);
    if (result) {
      bsModal.show();
      populateBookingModal(result);
    }
  });

});
/////////////////////////////////////////////////////// END OF REVIEW AND PAYMENT ///////////////////////////////////////////////////////


// document.getElementById("submitBtn").addEventListener("click", async function () {
//   const rating = document.querySelector('input[name="rating"]:checked');
//   const feedback = document.getElementById("feedbackText").value.trim();

//   if (!rating) {
//     alert("Please select a rating.");
//     return;
//   }

//   const ratingValue = rating.value;

//   try {
//     const response = await fetch(`http://livo.falakbhatti.com/public/api/customer-review`, {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({
//         service_rating: ratingValue,
//         comment: feedback,
//         service_id: "d106e6ac-9fa1-4082-a0d0-b880323a3371",
//         customer_id: "ab545916-a0c6-4c64-8dcc-747d6e25d1eb",
//       }),
//     });

//     if (!response.ok) {
//       throw new Error("Failed to submit feedback");
//     }

//     const result = await response.json();
//     console.log("Feedback submitted:", result);
//     // Optional: reset form or give user confirmation here
//   } catch (error) {
//     console.error("Error submitting feedback:", error.message);
//   }
// });

